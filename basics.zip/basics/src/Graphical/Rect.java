package Graphical;

import Calculate.Force.ForceGenerator;
import Calculate.Matrix2;
import Calculate.Multiply;
import Calculate.Rotate;
import Calculate.Vector2;

import java.awt.*;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
//TODO Change doubles into the floats may take a lot of time

public class Rect {
    //attributes that are needed for the object
    public float mass,inversemass;
    public float height,width;
    public Vector2 position,origin;
    private Color color;
    private float rotationCurrent, rotationPrevious;
    private Matrix2 rotMat;
    private String id;
    // physical quantities
    public Vector2 ForceAccum = new Vector2(0,0);
    public Vector2 linearVel = new Vector2(0,0);
    private float angularVel, angularDamping = 0f;
    private Vector2 liearDamping  = new Vector2(0,0);
    public ArrayList<Vector2> reactions = new ArrayList<Vector2>();

    private boolean fixedRot = false;

    private ArrayList<Vector2> points = new ArrayList<Vector2>();

    public void setRotationCurrent(float rotationCurrent) {
        this.rotationCurrent = rotationCurrent;
    }

    public int getHeight() {
        return (int) this.height;
    }

    public Vector2 getPosition() {
        return position;
    }

    public Vector2 getOrigin() {
        return origin;
    }

    public float getRotation() {
        return rotationCurrent;
    }

    public Rect(int xc, int yc, int h, int w, float m, Color c,String name){
        // assign all the attributes
        // TODO make getters and setters
        this.height = h;
        this.width = w;
        this.mass = m;
        this.id = name;
        // mass is 0 we use it for static objects
        // also use for validation of to avoid infinity error
        if (mass == 0.0f){this.inversemass = 0;}
        else{this.inversemass = 1/this.mass;}
        this.color = c;
        // TODO get rid off position may
        this.position = new Vector2(xc,yc);
        this.origin = new Vector2(xc,yc);
        origin.add(new Vector2(width/2,height/2));
        this.rotationCurrent = 0f;
        this.rotationPrevious = 0f;
        this.rotMat = new Matrix2(Math.cos(rotationCurrent),-Math.sin(rotationCurrent),Math.sin(rotationCurrent),Math.cos(rotationCurrent));
        //order of points 0,1,2,3 in left top, right top, right bottom, left bottom
        this.points.add(position);
        this.points.add(new Vector2(position.getX()+width, position.getY()));
        this.points.add(new Vector2(position.getX()+width,position.getY()+height));
        this.points.add(new Vector2(position.getX(),position.getY()+height));
    }
    public void draw(Graphics2D g2){
        g2.setColor(color);
        //  draws a line from 0 to 1 , 1 to 2, 2 to 3, 3 to 0
        //int[] new int[] {}
        g2.setStroke(new BasicStroke(5));
        for (int i= 1;i<4;i+=1){
            g2.draw(new Line2D.Float(points.get(i-1).getX(),points.get(i-1).getY(),
                    points.get(i).getX(),points.get(i).getY()));
        }
        g2.draw(new Line2D.Float(points.get(0).getX(),points.get(0).getY(),points.get(3).getX(),points.get(3).getY()));
        // think how to fill it inside
        //g2.fill(Polygon2D);

    }
    public ArrayList<Vector2> getPoints(){
        return this.points;
    }
    public void updatePoints(){
        //TODO sort out the order of rotation and translation maybe think about heavier use of matrices
        this.points.clear();
        this.points.add(this.position);
        this.points.add(new Vector2(this.position.getX()+this.width, this.position.getY()));
        this.points.add(new Vector2(this.position.getX()+this.width,this.position.getY()+this.height));
        this.points.add(new Vector2(this.position.getX(),this.position.getY()+this.height));
        for (int i = 0;i<4;i++){
            this.points.set(i,Rotate.rotation((double)this.rotationCurrent,this.points.get(i),this.origin));
        }
    }

    public void rotcheck(double f) {
        if (f> 1E-6){

        for (int i = 0; i < 4; i += 1) {
            updatePoints();
        }
        //float angle = this.rotationCurrent - this.rotationPrevious;
        //this.rotMat = new Matrix2(Math.cos(angle),-Math.sin(angle),Math.sin(angle),Math.cos(angle));
        this.position =Rotate.rotation((double)(this.rotationCurrent - this.rotationPrevious), this.points.get(0), this.origin) ;
        this.updateOrigin();
        this.rotationPrevious = this.rotationCurrent;
        }

    }
    // added new
    public void rotate(){
        // runs rotation procedure for all 4 points around origin
        for (int i = 0; i<4;i++){
            this.points.set(i,Rotate.rotation(this.rotationCurrent-this.rotationPrevious,this.points.get(i),this.origin));
        }
        this.rotationPrevious = this.rotationCurrent;
    }
    public void setLinearVel(Vector2 v) {
        if (this.mass != 0) {
            this.linearVel = v;
        }
    }
    public void updateOrigin(){
        this.origin = new Vector2(this.position);
    }

    public void updateForce(double dt){
        //if (this.mass ==0.0f)return;
        //Calculate linear velocity
        //System.out.println("force without reactions"+this.ForceAccum.x+" "+this.ForceAccum.y);
        //System.out.println("size of reactions"+this.reactions.size());
        for (int i = 0; i<this.reactions.size();i++){
            this.ForceAccum.add(reactions.get(i));
        }
        //System.out.println("force with reactions"+this.ForceAccum.x+" "+this.ForceAccum.y);
        Vector2 a = new Vector2(this.ForceAccum);
        a.mul(this.inversemass);
        // look at it closer
        Vector2 tmp = a.mulRet(dt);
        this.linearVel.add(a.mulRet(dt));

        this.position.add(new Vector2(this.linearVel.mulRet(dt)));
        updateOrigin();
        updatePoints();
        zeroAccum();
        //System.out.println(this.reactions.size());
        this.reactions.clear();
        }
    public void addForceAdditional(Vector2 reaction){
        this.reactions.add(new Vector2(reaction));
        //this.addForce(reaction);
    }
        public void addForce(Vector2 force){
        this.ForceAccum.add(force);


        }
        public void zeroAccum(){
        this.ForceAccum = new Vector2(0f,0f);

        }


    public void update(double dt){
        //this.rotationCurrent +=100*dt;
        this.updateForce(dt);
        this.rotcheck(dt);

    }
    public float getMass() {
        return mass;
    }

    public void setMass(float mass) {
        this.mass = mass;
    }

    public float getInversemass() {
        return inversemass;
    }


    public void setInversemass(float inversemass) {
        this.inversemass = inversemass;
    }
    public String getId(){
        return this.id;
    }
    public Vector2 getForceAccum(){
        return new Vector2(this.ForceAccum);
    }
    public int getWidth() {
        return (int)this.width;
    }
    public void setPosition(Vector2 val){
        this.position = new Vector2(val);
    }
}
