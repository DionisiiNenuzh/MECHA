package Graphical;
import Calculate.Force.Gravity;
import Calculate.Force.PhysicsHandler;
import Calculate.Vector2;
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;

public class Window extends JFrame implements Runnable{
// class that uses graphics
    Graphics2D g2;
    KL keyListener = new KL();
    objectsRegister objects = new objectsRegister();

    public Window(){
        // initialisation of the window
        this.setSize(Constants.SCREEN_WIDTH,Constants.SCREEN_HEIGHT);
        this.setTitle(Constants.SCREEN_TITLE);
        this.setVisible(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.addKeyListener(keyListener);
        g2 = (Graphics2D)this.getGraphics();


        JPanel panel = new JPanel();
        JButton button = new JButton("hello");
        panel.setBorder(BorderFactory.createEmptyBorder(30,30,10,30));
        panel.setLayout(new GridLayout(0,1));

        panel.add(button);
        button.getMousePosition();
        this.add(panel, BorderLayout.SOUTH);
        this.setTitle("hello");
        this.pack();
        this.setVisible(true);
    }

    // drawing of each object at separate coordinates
    public void update(double dt){
        Image dbImage = createImage(getWidth(),getHeight());
        Graphics dbg = dbImage.getGraphics();
        this.objects.update(dt);
        this.draw(dbg);
        g2.drawImage(dbImage,0,0,this);
// way how to listen to the keyboard presses

    }
    //LOOP that runs continuosly
    // needed for smoother frame rate
    public void draw(Graphics g){
        Graphics2D g2 = (Graphics2D)g;
        g2.setColor(Color.LIGHT_GRAY);
        g2.fillRect(0,0, Constants.SCREEN_WIDTH,Constants.SCREEN_HEIGHT);
        objects.draw(g2);
        //g2.fillPolygon(new int[] {900, 1000, 1050},new int[] {600,500,550},3);

        //Background color fill

        // drawing all objects that are on the screen
    }
    public void run(){
        double lastFrameTime = 0.0;
        this.objects.add(new Rect(300,150,50, 20, 1,Color.green,"green"));
        this.objects.add(new Rect(250,100,20, 20, 10f,Color.red,"red"));
        this.objects.add(new Rect(200,400,200, 600, 0f,Color.black,"ground"));

        PhysicsHandler Phsystem = new PhysicsHandler(new Vector2(0,49));
        //Phsystem.addObject(objects.queue.get[0]);

        while(true){
            // gets the time of one frame to update frame depending on dt
            double time = Time.getTime();
            double deltaTime = time - lastFrameTime;
            lastFrameTime = time;
            this.update(deltaTime);


        }
    }
}
