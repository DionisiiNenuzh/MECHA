package Graphical;
import Calculate.Force.ForceGenerator;
import Calculate.Force.ForceRegistry;
import Calculate.Force.Gravity;
import Calculate.Force.PhysicsHandler;
import Calculate.Vector2;
import java.awt.*;
import java.lang.reflect.Array;
import java.util.ArrayList;
public class objectsRegister {
    private int pointer,size;
    //TODO implement separately
    private ArrayList<Rect> queue;
    private PhysicsHandler PhSystem;
    public objectsRegister(){
        this.pointer = 0;
        this.size = Constants.MAXNUM_OBJECTS_ON_SCREEN;
        this.queue = new ArrayList<Rect>();

        this.PhSystem = new PhysicsHandler(new Vector2(0,Constants.GRAVITY_g));
    }
    public void add(Rect rect){
        if (this.pointer<this.size){
            this.queue.add(rect);
            this.pointer+=1;
            this.PhSystem.addObject(rect);
        }
    }
    public void update(double dt){

        this.PhSystem.update(dt);
        for (int i = 0;  i<queue.size();i = i+1){
            this.queue.get(i).update(dt);
                //this.queue.get(i).addForce(new Vector2(0,490));
        }
    }
    public void draw(Graphics2D g2){
        for (int i = 0;  i<queue.size();i = i+1){
            this.queue.get(i).draw(g2);
        }
    }
}
