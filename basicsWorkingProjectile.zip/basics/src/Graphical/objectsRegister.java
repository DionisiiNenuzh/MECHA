package Graphical;
import Calculate.Force.*;
import Calculate.Vector2;
import java.awt.*;
import GUI.Button;
import GUI.Characteristics;
import GUI.ObjectsDisplay;

import java.lang.reflect.Array;
import java.util.ArrayList;
public class objectsRegister {
    private int pointer,size;
    //TODO implement separately
    private ArrayList<Rect> queue;
    private ArrayList<Color> colors  = new ArrayList<Color>();
    private PhysicsHandler PhSystem;
    public ObjectsDisplay DisplayList;
    public ArrayList <Velocity> velocities;
    public ArrayList <FreeForce> forces;
    public objectsRegister(){
        this.pointer = 0;
        this.size = Constants.MAXNUM_OBJECTS_ON_SCREEN;
        this.queue = new ArrayList<Rect>();
        this.DisplayList = new ObjectsDisplay();
        this.initColors();
        this.velocities = new ArrayList<Velocity>();
        this.forces = new ArrayList<FreeForce>();

        this.PhSystem = new PhysicsHandler(new Vector2(0,Constants.GRAVITY_g));
    }
    public void initColors(){
        this.colors.add(Color.RED);
        this.colors.add(Color.ORANGE);
        this.colors.add(Color.MAGENTA);
        this.colors.add(Color.PINK);
        this.colors.add(Color.green);
        this.colors.add(Color.blue);
        this.colors.add(Color.yellow);
    }
    public void add(Rect rect){
        if (this.pointer<this.size){
            if (rect.getMass()!=0) {
                rect.setColor(this.colors.get(this.queue.size() % this.colors.size()));
            } else{rect.setColor(Color.black);}
            this.queue.add(rect);
            this.pointer+=1;
            this.DisplayList.add(rect);
            this.PhSystem.addObject(rect);
            System.out.println(this.queue.get(this.queue.size()-1).getId());
        }
    }
    public void checkVelocities(Rect rect){

        if (this.velocities.size()>0) {

            for (int i = 0; i < this.velocities.size(); i++) {
                //System.out.println("checking "+this.velocities.get(0).getName());
                //System.out.println(this.velocities.get(0).getSpeed().x+" "+this.velocities.get(0).getSpeed().y);
                if (!this.velocities.get(i).getUsed()){
                    System.out.println("l"+rect.getId()+"l l"+this.velocities.get(i).getName()+"l");

                }
                if (!this.velocities.get(i).getUsed()){
                    if (rect.getId().equals(this.velocities.get(i).getName())){
                        rect.setLinearVel(this.velocities.get(i).getSpeed());
                        this.velocities.get(i).setUsed(true);
                    }

                }

            }
        }
    }
    public void checkForces(){}


    public Rect getItem(int i){
        return this.queue.get(i);
    }
    public void create(Characteristics characteristics){
        //System.out.println(characteristics.name);
        if (characteristics.responding){
            //System.out.println("new object added");
            int[] properties = characteristics.getNumbers();
            this.queue.add(new Rect(properties[0],properties[1],100,100,properties[2],Color.pink,"pink"));
        }
    }
    public int getSize(){
        return this.queue.size();
    }
    public void addVelocity(float[] properties,String name){
        System.out.println("this velocity added to the registry");
        this.velocities.add(new Velocity(properties[0],properties[1],name));
    }
    public void addForce(float[] properties,String name){
        this.forces.add(new FreeForce(properties[0],properties[1],name));
    }

    public void update(double dt){
        for (int i = 0;  i<this.queue.size();i = i+1){
            //System.out.println("checking");
            this.checkVelocities(this.queue.get(i));     }


        this.PhSystem.update(dt);
        for (int i = 0;  i<this.queue.size();i = i+1){
            this.queue.get(i).update(dt);

            ;
                //this.queue.get(i).addForce(new Vector2(0,490));
        }
    }
    public void draw(Graphics2D g2){
        this.DisplayList.draw(g2);
        for (int i = 0;  i<this.queue.size();i = i+1){

            this.queue.get(i).draw(g2);
        }
    }
}
