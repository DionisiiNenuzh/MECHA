package Graphical;

public class Constants {
    public static final int SCREEN_HEIGHT = 1080;
    public static final int SCREEN_WIDTH = 1720;
    public static final String  SCREEN_TITLE = "MECHAN";
    public static final float GRAVITY_g = 25f;
    public static final float COEFFICIENT_RESTITUTION_DEFAULT = 0.007f;
    public static final int SCREEN_OFFSET = 150;

    public static final int MAXNUM_OBJECTS_ON_SCREEN = 15;


}
