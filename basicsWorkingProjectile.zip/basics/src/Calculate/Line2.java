package Calculate;

public class Line2 {
    private Vector2 end,start;
    //from start to the end
    private Vector2 direction;

    public Line2 (Vector2 end, Vector2 start){
        this.end = new Vector2(end);
        this.start = new Vector2(start);
        this.direction = new Vector2(end);
        this.direction.sub(start);

    }

    public Vector2 getEnd() {
        return end;
    }

    public Vector2 getStart() {
        return start;
    }

    public Vector2 getDirection() {
        return direction;
    }
}
