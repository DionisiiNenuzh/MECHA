package Calculate.Force;

import Calculate.*;
import Graphical.Constants;
import Graphical.Rect;
import com.sun.jdi.ArrayReference;

import java.util.ArrayList;

public class Impulse {
    public void resolve(Rect r1, Rect r2){

    }
    public void stationary(Rect rs, Rect rm){
        // TOdo validation of the 0 mass
        ArrayList<Vector2> points = rs.getPoints();
        ArrayList<Vector2> pointsMoving = rm.getPoints();
        Vector2 I, dir,C;
        Vector2 point2 = null;
        Vector2 point1 = null;
        C = new Vector2(0,0);
        EquationSolver e  = new EquationSolver();
        CollisionDetector c = new CollisionDetector();
        for (int i = 1;i<points.size();i++){
            dir = new Vector2(points.get(i-1));
            dir.mul(-1);
            dir.add(points.get(i));
            //System.out.println(dir.x+" "+ dir.y);
            RaycastResult Diagonal1 = c.LineAndRay(new Ray2(points.get(i-1),dir),new Line2(pointsMoving.get(0),pointsMoving.get(2)));
            RaycastResult Diagonal2 =  (c.LineAndRay(new Ray2(points.get(i-1),dir),new Line2(pointsMoving.get(1),pointsMoving.get(3))));
            // checks whether to add normal reactions or not;
            if (Diagonal2.getHit()) {
                point2 = new Vector2(Diagonal2.getPoint());
            }
            if (Diagonal1.getHit()) {
                point1 = new Vector2(Diagonal1.getPoint());
            }

            if (Diagonal1.getHit()||Diagonal2.getHit()) {

                C =  new Vector2(dir);
                //System.out.println("hit with line i" + i);
            }
        }
        I = new Vector2(e.equation(C.x,C.y,0));

        //System.out.println("Impulse direction"+I.x+" "+I.y);
        //System.out.println(rm.getForceAccum().x+" "+rm.getForceAccum().y+"                            force resultant");
        float magF = Multiply.dotProduct(I,rm.getForceAccum());
        Vector2 R = new Vector2(I);
        //System.out.println("scale factor"+(-magF/I.getMagnitude()));

        R.mul(-magF/I.getMagnitude());
        if (point1!=null){
            rm.addForceAdditional(R,rs,point1);

            Vector2 Tocentre=new Vector2(rs.getOrigin());
            Tocentre.sub(point1);
            if (Multiply.dotProduct(R,Tocentre)<0){
                R.mul(-2);
                //I.mul(-1);
            }
        }else   if        (point2!=null){
            rm.addForceAdditional(R,rs,point2);
            Vector2 Tocentre=new Vector2(rs.getOrigin());
            Tocentre.sub(point2);
            if (Multiply.dotProduct(R,Tocentre)<0){
                R.mul(-2);
                //I.mul(-1);
            }
        }
        if (c.pointInRectangle(rm.origin,rs)){
            R.mul(100f);
        }

        //R.mul(1f);
        //System.out.println("reaction direction"+R.x+" "+R.y);
        //System.out.println("resultant before"+rm.getForceAccum().x+" "+rm.getForceAccum().y);
        // applies a new force to the Object
        //rm.addForceAdditional(R,rs);
        //System.out.println("resultant after"+rm.getForceAccum().x+" "+rm.getForceAccum().y);
        // cancellation of velocity in the direction of the plane
        Vector2 V = new Vector2(I);
        float magVel = Multiply.dotProduct(I,rm.linearVel);

        V.mul(-magVel/I.getMagnitude());
        rm.linearVel.add(V);

        I.normalise();
        //I.mul(-Math.min(rm.width,rm.height)*0.1);
        I.mul(-Multiply.dotProduct(rm.linearVel,I.mulRet(-1.5)));
        rm.origin.add(I);

    }
    public void impulse(Rect r1, Rect r2){
        // we get centres line in vectors
        Vector2 I = new Vector2(r1.getOrigin());
        I.sub(r2.getOrigin());
        Vector2 C = EquationSolver.equation(I.getX(),I.getY(),0);
        float xa, ya, xb, yb,a1,a2,b1,b2,c1,c2,ca, cb;
        c1 = Constants.COEFFICIENT_RESTITUTION_DEFAULT*(
                Multiply.dotProduct(I,r1.linearVel)-Multiply.dotProduct(I,r2.linearVel));
        //TODO check whether it is zero division
        ca = Multiply.dotProduct(C,r1.linearVel);
        cb = Multiply.dotProduct(C,r2.linearVel);
        c1 -=I.x/C.x*(ca+cb);
        c1 = c1*Constants.COEFFICIENT_RESTITUTION_DEFAULT;
        a1 = I.y-C.y/C.x*I.x;

        b1 = a1;
        // check whether mass is zero
        c2 = r1.getMass()*Multiply.dotProduct(C,r1.linearVel)+ r2.getMass()*Multiply.dotProduct(C,r2.linearVel);
        c2 -= ca*r1.getMass() + cb*r2.getMass();
        a2 = r1.getMass()*(-C.y/C.x+C.y);
        b2 = r2.getMass()*(-C.y/C.x+C.y);
        Vector2 result = EquationSolver.simultaneous_equations(a1,b1,c1,a2,b2,c2);
        System.out.println("a1 is "+a1);
        System.out.println("a2 is "+a2);
        System.out.println("b1 is "+b1);
        System.out.println("b2 is "+b2);
        System.out.println("c1 is "+c1);
        System.out.println("c2 is "+c2);

        ya = result.x;
        System.out.println("ya :"+ya);
        yb = result.y;
        System.out.println("yb :"+yb);
        xa = (ca-C.y*ya)/C.x;
        xb = (cb-C.y*yb)/C.x;
        System.out.println(I.x+" "+ I.y);

        r1.setLinearVel(new Vector2(xa,ya));
        r2.setLinearVel(new Vector2(xb,yb));
        System.out.println("there is a change in velocity "+r1.linearVel.x +" "+ r1.linearVel.y +"  and position "+r1.getPosition().x+" "+r1.getPosition().y);

        System.out.println("position "+r2.getPosition().x+" "+r2.getPosition().y);

    }
}
