package Calculate.Force;

import Calculate.Vector2;

public class Velocity {
    private Vector2 speed;
    private String name;
    private boolean used;
    public Velocity(float velocity, float angle,String name){
        System.out.println(velocity+" "+angle);
        this.speed = new Vector2((float)(Math.cos(-angle*Math.PI/180)*velocity),(float)-(Math.sin(angle*Math.PI/180)*velocity));
        System.out.println("here is the velocity instantiated"+this.speed.x+" "+this.speed.y);
        this.name = name;
        this.used = false;
    }
    public String getName(){
        return this.name;
    }
    public Vector2 getSpeed(){
        return new Vector2(this.speed);
    }
    public void setUsed(boolean val){
        this.used = val;
    }
    public boolean getUsed(){
        return this.used;
    }


}
