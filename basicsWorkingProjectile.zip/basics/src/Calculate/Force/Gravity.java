package Calculate.Force;

import Calculate.Vector2;
import Graphical.Rect;

public class Gravity implements ForceGenerator{
    private Vector2 gravity;


    public Gravity(Vector2 force){
        this.gravity = force;

    }

    @Override
    public void updateForce(Rect rect, double dt) {
        // f = m *a
        rect.addForce(new Vector2(gravity).mulRet(rect.getMass()));
    }
}
