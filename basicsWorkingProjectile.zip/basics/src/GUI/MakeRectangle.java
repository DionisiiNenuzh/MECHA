package GUI;

import Calculate.Vector2;
import Graphical.Rect;
import Graphical.objectsRegister;

import javax.swing.*;
import javax.swing.plaf.basic.BasicViewportUI;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyListener;

public class MakeRectangle extends JFrame{
    private JTextField Xposition;
    private JTextField Yposition;
    private JTextField Mass;
    private JButton createObjectButton;
    public JPanel Details;
    private JLabel XLabel;
    private JLabel Ylabel;
    private JLabel MassLabel;
    private JLabel Name;
    private JTextField NameField;
    public objectsRegister objects;
    public String nameOfObject;
    private int[] Numbers = new int[3];
    private boolean[] complete = {false,false,false,false};
    public boolean ready ;
    public Button Trigger = null;
    public void createUIComponents(){}

    public MakeRectangle(objectsRegister obj, Button Trig){
        this.objects = obj;

        //initComponents();
        //MakeRectangle win = new MakeRectangle();
        this.Trigger = Trig;
        this.ready = false;
        this.Xposition.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("x in");
                try{Numbers[0] = Integer.parseInt(Xposition.getText());
                    Completion(0,true);
                    changeColor(XLabel);}
                catch (Exception exc){
                    JOptionPane.showMessageDialog(null,"This field contains only integer numbers");
                    Completion(0,false);;}}});
        this.Yposition.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("y in");
                try{Numbers[1] = Integer.parseInt(Yposition.getText());
                    Completion(1,true);
                    changeColor(Ylabel);}
                catch (Exception exc){
                    JOptionPane.showMessageDialog(null,"This field contains only integer numbers");
                    Completion(1,false);}}});
        this.Mass.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("mass in");
                try{Numbers[2] = Integer.parseInt(Mass.getText());
                    Completion(2,true);
                changeColor(MassLabel);
                }
                catch (Exception exc){
                    JOptionPane.showMessageDialog(null,"This field contains only integer numbers");
                    Completion(2,false);}
                System.out.println(getNumbers()[0]+" "+getNumbers()[1]+" "+ getNumbers()[2]);}});

        this.createObjectButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("rectangle created");
                if (ready){
                    System.out.println(" is already ready");
                }
                isReady();
                if (getReady()) {
                    makeAnObject();
                    setCreated();
                }else{
                    JOptionPane.showMessageDialog(null, "Not all fields completed");
                }
                if (getReady()){
                    System.out.println("definetely ready");
                }
                System.out.println(getNumbers()[0]+" "+getNumbers()[1]+" "+ getNumbers()[2]);}});
        //this.initComponents();

        this.NameField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                nameOfObject = NameField.getText();
                output();
                traverseObjects();
                checkName();
                output();
            }
        });
    }

    /*public void update(){
        if (this.ready){
            System.out.println(this.getNumbers()[0]+" "+this.getNumbers()[1]+" "+ this.getNumbers()[2]);
        }
    }*/
    public void output(){
        System.out.println("name of created object "+this.nameOfObject);
    }
    public void checkName(){
        if (this.nameOfObject== null){
            Completion(3,false);
        }
        else{
            Completion(3,true);
        }

    }
    public void traverseObjects(){
        boolean hello = true;
        for (int  i = 0;   i< this.objects.getSize() ;  i++) {
            if (this.nameOfObject.equals(this.objects.getItem(i).getId())){
                JOptionPane.showMessageDialog(null,"This name already exists");
                hello = false;
            }
        }
        if (!hello){
            this.nameOfObject = null;
            Completion(3,false);
        }
    }
    public void setCreated(){
        System.out.println("name of object is "+this.Trigger.name);
        this.Trigger.response.activate();
        //this.setVisible(false);
    }
    public void setButton(Button button){
        System.out.println("the new button is set");
        this.Trigger = button;
    }
    public void makeAnObject(){
        if (this.ready) {
            int[] parameter = this.Numbers;
            this.objects.add(new Rect(parameter[0], parameter[1], 100, 100, parameter[2], Color.blue, this.nameOfObject));
        }//register.add()
        //register.

    }
    public void update(){
        this.setVisible(this.Trigger.response.Active);
        if (this.Trigger.response.Active){

        }
    }

    public void Completion(int i,boolean val){
        this.complete[i] = val;

    }
    public void isReady(){
        this.setReady();
        for (int i = 0; i < 4; i++) {
            if (!this.complete[i]){
                //System.out.println("not completed yet "+i);
                this.setUnready();
            }
        }

    }
    public void changeColor(JLabel field){
        System.out.println("changing color");
        field.setBackground(Color.green);
    }

public void setUnready(){
    this.ready = false;
}
    public void setReady(){
        this.ready = true;
        this.Trigger.response.respond = true;
    }
public boolean getReady(){
    return this.ready;
}
    public int[] getNumbers(){
        return this.Numbers.clone();
    }
    public boolean[] getComplete(){
        return this.complete.clone();
    }
    public void initComponents(){
        this.setContentPane(new MakeRectangle(this.objects,this.Trigger).Details);
        //this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        this.pack();
        /*
        Xposition.addKeyListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e ){
            try{Numbers[0] = Integer.parseInt(Xposition.getText());}
            catch (Exception exc){      JOptionPane.showMessageDialog(null,"This field contains only integer numbers");}      } });

         */



    }
}
