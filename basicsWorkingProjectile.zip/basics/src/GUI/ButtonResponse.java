package GUI;

import Calculate.Vector2;

public class ButtonResponse {
    public boolean Active = false;
    public boolean respond;
    public Panel panel  = null;
    public ButtonResponse(){
        this.respond= true;

    }
    public void setRespond(boolean v){
        this.respond = v;
    }
    public void Responding(){

    }

    public void activate(){
        this.Active = !this.Active;
        System.out.println("this activated");

    }
    public Panel getPanel(){
        return this.panel;
    }
    public void DropDown(){

    }
    public boolean getActive(){
        return this.Active;
    }

}

