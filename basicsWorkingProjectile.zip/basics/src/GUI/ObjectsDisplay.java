package GUI;

import Graphical.Rect;

import java.awt.*;
import java.util.ArrayList;

public class ObjectsDisplay {
    public ArrayList<String> objects;
    public ArrayList<Color> colors;
    //public
    public ObjectsDisplay(){
        this.objects = new ArrayList<String>();
        this.colors = new ArrayList<Color>();

    }
    public void draw(Graphics2D g2){
        //fills background
        g2.setColor(Color.gray);
        g2.fillRect(10,200,130,500);
        int posX = 20;
        int posY = 210;
        for (int i = 0; i < this.objects.size(); i++) {
            g2.setColor(Color.black);
            g2.drawString(this.objects.get(i),posX,posY);
            posY+=10;
            g2.setColor(this.colors.get(i));
            g2.drawRect(posX,posY,30,30);
            posY +=45;
        }
    }
    public void add(Rect rect){
        if (rect.getId() != null) {
            this.objects.add(rect.getId());
            this.colors.add(rect.getColor());
        }

    }

}
