package GUI;

import Graphical.objectsRegister;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MakeForce extends JFrame{

    private JButton CreateForce;
    private JTextField NameOfObject;
    private JTextField MagnitudeOfForce;
    private JTextField AngleInDegrees;
    private JPanel Details;
    public objectsRegister objects;
    public String nameOfObject;
    private float[] Numbers = new float[3];
    private boolean[] complete = {false,false,false};
    public boolean ready ;
    public Button Trigger = null;
    public MakeForce(objectsRegister obj, Button Trig) {
        this.objects = obj;
        this.Trigger = Trig;
        this.ready = false;

        NameOfObject.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                nameOfObject = NameOfObject.getText();
                traverseObjects();
            }
        });
        MagnitudeOfForce.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{Numbers[0] = Float.parseFloat(MagnitudeOfForce.getText());
                    Completion(1,true);
                    System.out.println("input for mag of force is in");
                    }
                catch (Exception exc){
                    JOptionPane.showMessageDialog(null,"This field contains only integer numbers");
                    Completion(1,false);;}}});

        AngleInDegrees.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{Numbers[1] = Float.parseFloat(AngleInDegrees.getText());
                    Completion(2,true);
                    System.out.println("input for mag of force is in");
                }
                catch (Exception exc){
                    JOptionPane.showMessageDialog(null,"This field contains only integer numbers");
                    Completion(2,false);;}}});

        CreateForce.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                isReady();
                if (getReady()){
                    makeAForce();
                    setCreated();
                    System.out.println("force has been added successfully");
                }else{
                    JOptionPane.showMessageDialog(null, "Not all fields completed");
                }}});
    }
    public void setButton(Button b){
        this.Trigger =b;

    }
    public void makeAForce(){
        System.out.println("this force has been created for"+ this.nameOfObject);
        this.objects.addForce(this.getNumbers(),this.nameOfObject);
    }
    public void initComponents(){
        this.setContentPane(new MakeForce(this.objects,this.Trigger).Details);
        //this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        this.pack();

    }
    public void setCreated(){
        System.out.println("name of object is "+this.Trigger.name);
        this.Trigger.response.activate();
        //this.setVisible(false);
    }
    public void update(){
        this.setVisible(this.Trigger.response.Active);
        if (this.Trigger.response.Active){

        }
    }
    public void Completion(int i,boolean val){
        this.complete[i] = val;
    }
    public void isReady(){
        this.setReady();
        for (int i = 0; i <3; i++) {
            if (!this.complete[i]){
                //System.out.println("not completed yet "+i);
                this.setUnready();
            }     }
    }
    public void traverseObjects() {
        boolean found = false;
        if (this.nameOfObject!=null||this.nameOfObject.equals("")){
        for (int i = 0; i < this.objects.getSize(); i++) {
            if (this.nameOfObject.equals(this.objects.getItem(i).getId())) {
                found = true;
            }}}        else{found = false;}
        if (!found){
            JOptionPane.showMessageDialog(null, "This name does not exist/not defined");
        }
        this.Completion(0,found);
    }
    public void setReady(){
        this.ready = true;
        this.Trigger.response.respond = true;
    }
    public void setUnready(){
        this.ready = false;
        this.Trigger.response.respond = false;
    }
    public boolean getReady(){
        return this.ready;
    }
    public float[] getNumbers(){
        return this.Numbers.clone();
    }
    public boolean[] getComplete(){
        return this.complete.clone();
    }

}
