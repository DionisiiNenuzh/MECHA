package GUI;

import Calculate.Force.CollisionDetector;
import Calculate.Vector2;
import Graphical.KL;
import Graphical.Rect;

import java.awt.*;

public class InputField extends Button {
    public String input = "hello";
    public int limit;

    public InputField(Vector2 position, Vector2 size, String name, ButtonResponse b, int lim) {
        super(position, size, name, b);
        this.limit = lim;
    }

    public void warning() {

    }
    public void draw(Graphics2D g2){

        g2.setColor(Color.yellow);
        g2.setStroke(new BasicStroke(5));
        g2.fillRect((int) this.position.getX(), (int) this.position.getY(), (int) this.size.getX(), (int) this.size.getY());
        g2.setColor(Color.darkGray);
        if (this.input!=null) {
            g2.drawString(this.input, (int) this.position.getX() + 20, (int) this.position.getY() + 20);
        }
        if (this.SetHighlight) {
            this.highlight(g2, Color.green);
        }

            //System.out.println(this.response.panel.position.x+" "+this.response.panel.position.y);

    }

 public void inputKey(String c){
        if (this.response.getActive()){

            this.updateInput(c);
        }
    }
    public void updateInput(String c){
        //  check whether it adds
        System.out.println("string inputed "+c);

        if ((this.input.length()<=this.limit+6 )&&(c!=null)){
            this.input +=c;
            try {
                Integer.parseInt(c);
                this.input +=c;
            }
            catch( Exception e ) {
                this.warning();
            }


        }


    }
    public void CheckHighlight(Vector2 p, boolean click,String ch){
        CollisionDetector c = new CollisionDetector();
        if (c.pointInRectangle(p, new Rect((int) this.getPosition().x, (int) this.getPosition().y, (int) this.getSize().y, (int) this.getSize().x,
                10, Color.red, ""))) {
            this.SetHighlight = true;
            if (click) {
                this.response.activate();

            }
            //System.out.println("yes");
        } else {
            //System.out.println("not");
            this.SetHighlight = false;
        }
        if (this.name.equals("Create")||this.response.panel!=null) {
            //System.out.println(this.response.panel.size.x+" "+ this.response.panel.size.y);
            this.response.panel.OnMenu(p, click,ch);
            if (this.response.getActive()) {

            }

        }
    }
}
