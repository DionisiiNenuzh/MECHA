package GUI;

import Graphical.objectsRegister;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MakeVelocity extends JFrame {
    private JPanel Details;
    private JButton CreateVelocity;
    private JTextField NameOfObject;
    private JTextField MagnitudeOfVelocity;
    private JTextField AngleToRotation;
    public objectsRegister objects;
    public String nameOfObject;
    private float[] Numbers = new float[3];
    private boolean[] complete = {false,false,false};
    public boolean ready ;
    public Button Trigger = null;

    public MakeVelocity(objectsRegister obj, Button Trig) {
        this.objects = obj;
        this.Trigger = Trig;
        this.ready = false;
        NameOfObject.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                nameOfObject = NameOfObject.getText();
                traverseObjects();
                if (!getComplete(0)){
                JOptionPane.showMessageDialog(null, "This name does not exist/not defined");
            }}
        });
        MagnitudeOfVelocity.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{Numbers[0] = Float.parseFloat(MagnitudeOfVelocity.getText());
                    Completion(1,true);
                }
                catch (Exception exc){
                    JOptionPane.showMessageDialog(null,"This field contains only integer numbers");
                    Completion(1,false);;}}});

        AngleToRotation.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{Numbers[1] = Float.parseFloat(AngleToRotation.getText());
                    Completion(2,true);
                }
                catch (Exception exc){
                    JOptionPane.showMessageDialog(null,"This field contains only integer numbers");
                    Completion(2,false);;}}});
        CreateVelocity.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                isReady();
                if (getReady()){
                    makeAVelocity();
                    setCreated();
                    System.out.println("Velocity has been added successfully");
                    System.out.println(getNumbers()[0]+" "+getNumbers()[1]);
                }else{
                    JOptionPane.showMessageDialog(null, "Not all fields completed");
                }
            }
        });
    }
    public void setButton(Button b){
        this.Trigger =b;

    }
    public void makeAVelocity(){
        System.out.println("this Velocity has been created for"+ this.nameOfObject);
        this.objects.addVelocity(this.getNumbers(),this.nameOfObject);
}
    public void initComponents(){
        this.setContentPane(new MakeVelocity(this.objects,this.Trigger).Details);
        //this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        this.pack();

    }
    public void setCreated(){
        System.out.println("name of object is "+this.Trigger.name);
        this.Trigger.response.activate();
        //this.setVisible(false);
    }
    public void update(){
        this.setVisible(this.Trigger.response.Active);
        if (this.Trigger.response.Active){

        }
    }
    public void Completion(int i,boolean val){
        this.complete[i] = val;
    }
    public void isReady(){
        this.setReady();
        for (int i = 0; i <3; i++) {
            if (!this.complete[i]){
                //System.out.println("not completed yet "+i);
                this.setUnready();
            }     }
    }
    public void traverseObjects() {
        boolean found = false;
        if (this.nameOfObject!=null||this.nameOfObject.equals("")){
            for (int i = 0; i < this.objects.getSize(); i++) {
                if (this.nameOfObject.equals(this.objects.getItem(i).getId())) {
                    found = true;
                }}}        else{found = false;}
        this.Completion(0,found);
        if (!found){

        }

    }
    public void setReady(){
        this.ready = true;
        this.Trigger.response.respond = true;
    }
    public void setUnready(){
        this.ready = false;
        this.Trigger.response.respond = false;
    }
    public boolean getReady(){
        return this.ready;
    }
    public float[] getNumbers(){
        return this.Numbers.clone();
    }
    public boolean getComplete(int i){
        return this.complete[i];
    }

}
