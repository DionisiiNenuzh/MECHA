package GUI;

import Calculate.Vector2;

import java.awt.*;

public class CreateButton extends ButtonResponse {
    public Panel dropdown;
    public Vector2 position,size;
    public boolean OpenedMenu;

    public CreateButton(Vector2 position, Vector2 size) {
        super();
        // takes the position in the left bottom corner of the button
        Vector2 relativePos = new Vector2(position);
        relativePos.add(size);
        this.panel = new Panel(relativePos);
        this.panel.add(new Button(new Vector2(100,100),new Vector2(140,25),"Moving Object",new ButtonResponse()));
        this.panel.add(new Button(new Vector2(100,100),new Vector2(140,25),"Stationary ground",new ButtonResponse()));
        this.panel.add(new Button(new Vector2(100,100),new Vector2(140,25),"Force",new ButtonResponse()));
        this.panel.add(new Button(new Vector2(100,100),new Vector2(140,25),"Velocity",new ButtonResponse()));

        System.out.println(this.panel.buttons.size());
        this.OpenedMenu = false;
    }
    public Panel getPanel(){
        return  this.panel;
    }

    public void activate(){

        this.Active = !(this.Active);

        this.OpenedMenu =!(this.OpenedMenu);
        /*if (OpenedMenu){
            Vector2 relativePos = new Vector2(this.position);
            relativePos.add(size);
            this.panel = new Panel(relativePos);
        }8*/
    }




    }

