package Test;

public class TestInputWindow {
}
