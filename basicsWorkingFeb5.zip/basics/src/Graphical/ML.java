package Graphical;

import Calculate.Vector2;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class ML implements MouseListener {
    public boolean pressed, released, clicked;


    @Override
    public void mouseClicked(MouseEvent e) {
        //this.clicked = true;


    }

    @Override
    public void mousePressed(MouseEvent e) {
        //System.out.println("clicked");
        this.pressed = true;



    }

    @Override
    public void mouseReleased(MouseEvent e) {
        this.released = true;
        this.pressed  = false;



        /*
        if (this.pressed){
            this.clicked = true;
            this.pressed = false;

        }
        else{this.clicked = false; }*/





    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
    public Vector2 getLocation(){
        return new Vector2(MouseInfo.getPointerInfo().getLocation().x,MouseInfo.getPointerInfo().getLocation().y);
    }
    public boolean getClick(){
        if (!this.pressed&&this.released){
            this.clicked = true;
            this.released = false;
        }
        else{
            this.clicked = false;
        }
        return this.clicked;
    }

}
