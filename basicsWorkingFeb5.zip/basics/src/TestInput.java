
import GUI.MakeRectangle;
import GUI.MakeRectangle2;

import javax.swing.*;


public class TestInput {
    public static void main(String[] args) {
        MakeRectangle2 win = new MakeRectangle2();
        win.setContentPane(new MakeRectangle2().Details);
        win.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        win.pack();
        win.setVisible(true);
        boolean done = false;
        /*
        while(!done){
            for (int i = 0; i < 3; i++) {
                done = true;
                if (!win.getComplete()[i]){
                    done = false;
                }
            }
            System.out.println(win.getNumbers()[0]+" "+win.getNumbers()[1]+" "+ win.getNumbers()[2]);
            if (done){
                System.out.println(win.getNumbers()[0]+" "+win.getNumbers()[1]+" "+ win.getNumbers()[2]);
            }
        }*/
    }
}
