package GUI;

public class PlayButton extends ButtonResponse {
    public PlayButton(){
        super();
    }
    public boolean Active = false;
    public void activate(){
        this.Active = !(this.Active);
    }
    public boolean getActive(){
        return  this.Active;
    }
}
