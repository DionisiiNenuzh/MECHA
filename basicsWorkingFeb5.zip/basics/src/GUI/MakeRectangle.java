package GUI;

import Calculate.Vector2;
import Graphical.Rect;
import Graphical.objectsRegister;

import javax.swing.*;
import javax.swing.plaf.basic.BasicViewportUI;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyListener;

public class MakeRectangle extends JFrame{
    private JTextField Xposition;
    private JTextField Yposition;
    private JTextField Mass;
    private JButton createObjectButton;
    public JPanel Details;
    public objectsRegister objects;
    private int[] Numbers = new int[3];
    private boolean[] complete = {false,false,false};
    public boolean ready ;
    public Button Trigger;
    public void createUIComponents(){}

    public MakeRectangle(objectsRegister obj){
        this.objects = obj;

        //initComponents();
       //MakeRectangle win = new MakeRectangle();
        this.Trigger = new Button(new Vector2(0,0),new Vector2(0,0),"hello", new ButtonResponse());
        this.ready = false;
        this.Xposition.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("x in");
                try{Numbers[0] = Integer.parseInt(Xposition.getText());
                    Completion(0,true);
                    Xposition.setDisabledTextColor(Color.green);}
                catch (Exception exc){
                    JOptionPane.showMessageDialog(null,"This field contains only integer numbers");
                    Completion(0,false);;}}});
        this.Yposition.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("y in");
                try{Numbers[1] = Integer.parseInt(Yposition.getText());
                    Completion(1,true);
                    Yposition.setDisabledTextColor(Color.green);}
                catch (Exception exc){
                    JOptionPane.showMessageDialog(null,"This field contains only integer numbers");
                    Completion(1,false);}}});
        this.Mass.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("mass in");
                try{Numbers[2] = Integer.parseInt(Mass.getText());
                    Completion(2,true);
                changeColor(Mass);}
                catch (Exception exc){
                    JOptionPane.showMessageDialog(null,"This field contains only integer numbers");
                    Completion(2,false);}
                System.out.println(getNumbers()[0]+" "+getNumbers()[1]+" "+ getNumbers()[2]);}});

        this.createObjectButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("rectangle created");
                if (ready){
                    System.out.println(" is already ready");
                }
                isReady();
                makeAnObject();
                if (getReady()){
                    System.out.println("definetely ready");
                }
                System.out.println(getNumbers()[0]+" "+getNumbers()[1]+" "+ getNumbers()[2]);}});

            }
    /*public void update(){
        if (this.ready){
            System.out.println(this.getNumbers()[0]+" "+this.getNumbers()[1]+" "+ this.getNumbers()[2]);
        }
    }*/
    public void setButton(Button button){
        this.Trigger = button;
    }
    public void makeAnObject(){
        int [] parameter = this.Numbers;
        this.objects.add(new Rect(parameter[0],parameter[1],100,100,parameter[2], Color.blue, "blue"));
        //register.add()
        //register.

    }

    public void Completion(int i,boolean val){
        this.complete[i] = val;

    }
    public void isReady(){
        this.setReady();
        for (int i = 0; i < 3; i++) {
            if (!this.complete[i]){
                //System.out.println("not completed yet "+i);
                this.setUnready();
            }
        }

    }
    public void changeColor(JTextField field){
        field.setDisabledTextColor(Color.green);
    }

public void setUnready(){
    this.ready = false;
}
    public void setReady(){
        this.ready = true;
        this.Trigger.response.respond = true;
    }
public boolean getReady(){
    return this.ready;
}
    public int[] getNumbers(){
        return this.Numbers.clone();
    }
    public boolean[] getComplete(){
        return this.complete.clone();
    }
    public void initComponents(){
        this.setContentPane(new MakeRectangle(this.objects).Details);
        //this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        this.pack();
        /*
        Xposition.addKeyListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e ){
            try{Numbers[0] = Integer.parseInt(Xposition.getText());}
            catch (Exception exc){      JOptionPane.showMessageDialog(null,"This field contains only integer numbers");}      } });

         */



    }
}
