package GUI;

import Calculate.Force.CollisionDetector;
import Calculate.Vector2;
import Graphical.KL;
import Graphical.Rect;

import javax.swing.*;
import java.awt.*;

public class Button {
    public Vector2 position, size;
    public String name;
    public boolean SetHighlight = false;
    public ButtonResponse response ;
    public MakeRectangle input;

    public Button(Vector2 position, Vector2 size, String name, ButtonResponse response) {
        this.position = position;
        this.name = name;
        this.size = size;
        this.response = response;
        this.input = null;
    }

    public Button(Button b) {
        this.position = b.getPosition();
        this.name = b.name;
        this.size = b.getSize();
        this.response = b.response;
    }

    public void draw(Graphics2D g2) {
        g2.setColor(Color.pink);
        g2.setStroke(new BasicStroke(5));

        g2.fillRect((int) this.position.getX(), (int) this.position.getY(), (int) this.size.getX(), (int) this.size.getY());
        g2.setColor(Color.darkGray);
        g2.drawString(this.name, (int) this.position.getX() + 20, (int) this.position.getY() + 20);
        if (this.SetHighlight) {
            this.highlight(g2,Color.yellow);
        }
        if (this.response.getActive()){
            this.setInputWindow();
        }
        if (this.response.getActive() && this.name.equals("Create")) {
            this.response.getPanel().position = new Vector2(this.position);
            Vector2 relativePos = new Vector2(position);
            relativePos.add(size);
            this.response.panel.setPosition(relativePos);

            //System.out.println("draws");
            this.response.panel.draw(g2);

            //System.out.println(this.response.panel.position.x+" "+this.response.panel.position.y);
        }


    }
    public void AssignInputWindow(MakeRectangle m){
        this.input  = m ;
    }

    public void highlight(Graphics2D g2,Color color) {
        g2.setColor(color);
        g2.setStroke(new BasicStroke(5));

        g2.drawRect((int) this.position.getX(), (int) this.position.getY(), (int) this.size.getX(), (int) this.size.getY());


    }

    public Vector2 getPosition() {
        return new Vector2(this.position);
    }

    public Vector2 getSize() {
        return new Vector2(this.size);
    }

    public void setSize(Vector2 size) {
        this.size = new Vector2(size);
    }

    public void setPosition(Vector2 position) {
        this.position = new Vector2(position);
    }
    public void inputKey(String c){

    }

    public void DropDown() {

    }
    public void setInputWindow( ){
        if (this.input!=null&&this.response.Active){
        this.input.setVisible(true);
    }

    }
    public boolean getReady(){
        return this.input.getReady();
    }
    public void checkInput(){
        this.input.isReady();
    }
    public void getRespond(){
        this.input.isReady();
        if (this.input.getReady()){
            System.out.println("should be out");
            this.response.setRespond(true);
        }
    }

    public int[] getNumbers(MakeRectangle win){
        return win.getNumbers().clone();
    }


    public void CheckHighlight(Vector2 p, boolean click, String ch) {
        CollisionDetector c = new CollisionDetector();
        if (c.pointInRectangle(p, new Rect((int) this.getPosition().x, (int) this.getPosition().y, (int) this.getSize().y, (int) this.getSize().x,
                10, Color.red, ""))) {
            this.SetHighlight = true;
            if (click) {
                this.response.activate();
            }
            //System.out.println("yes");
        } else {
            //System.out.println("not");
            this.SetHighlight = false;
        }
        if (this.name.equals("Create")||this.response.panel!=null) {
            //System.out.println(this.response.panel.size.x+" "+ this.response.panel.size.y);
            this.response.panel.OnMenu(p, click,ch);
            if (this.response.getActive()) {

            }

        }
    }
}


