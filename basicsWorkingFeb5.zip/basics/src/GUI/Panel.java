package GUI;

import Calculate.Force.CollisionDetector;
import Calculate.Vector2;
import Graphical.KL;
import Graphical.Rect;

import java.awt.*;
import java.util.ArrayList;

public class Panel {
    public ArrayList<Button> buttons = new ArrayList<Button>();
    public Vector2 position,size;
    private Vector2 buttonSpacing = new Vector2(0,30);
    public Panel(Vector2 v){
        //System.out.println("position"+v.x+" "+v.y);
        this.position = new Vector2(v);
        this.size = new Vector2(this.buttonSpacing);


    }
    public void init(){
        //System.out.println(this.buttons.size());
        this.buttons.get(0).setPosition(this.position);
        this.size.add(this.buttons.get(0).size);
        if (this.buttons.size()>1) {
            for (int i = 1; i < this.buttons.size(); i++) {
                Vector2 pos = new Vector2(this.buttons.get(i - 1).getPosition());
                pos.add(this.buttonSpacing);
                this.buttons.get(i).setPosition(pos);
                this.size.add(this.buttons.get(i).size);
            }
        }

    }
    public void add(Button b){
        this.buttons.add(b);

    }
    public void off(){
        for (int i = 0; i < this.buttons.size(); i++) {
            this.buttons.get(i);

        }
    }
    public void draw(Graphics2D g2){
        this.init();
        for (int i = 0;i<this.buttons.size(); i++){
            this.buttons.get(i).draw(g2);
        }
    }
    public void OnMenu( Vector2 point,  boolean click,String ch){
        CollisionDetector c = new CollisionDetector();

        if (c.pointInRectangle(point,new Rect((int)this.position.x,(int)this.position.y,(int)this.size.y,(int)this.size.x,
                10,Color.red,""))){
        for (int i = 0;i<this.buttons.size(); i++){
            this.buttons.get(i).CheckHighlight(point,click,ch);
        }
    } else{
            //this.buttons.off();
        }


    }
    public void inputKey(String c){}
    public void setPosition(Vector2 v){
        this.position = new Vector2(v);
    }
}
