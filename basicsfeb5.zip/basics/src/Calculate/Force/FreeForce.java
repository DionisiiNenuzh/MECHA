package Calculate.Force;

import Calculate.Vector2;
import Graphical.Rect;

public class FreeForce implements ForceGenerator{
    private Vector2 force;
    public String body;
    public FreeForce(Vector2 force,String index){
        this.force = force;
        this.body = index;
    }


    @Override
    public void updateForce(Rect rect, double dt) {
        rect.addForce(this.force);

    }
}
