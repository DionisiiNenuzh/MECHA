package Calculate.Force;

import Calculate.*;
import Graphical.Rect;

import java.awt.*;
import java.util.ArrayList;

public class CollisionDetector {

        public static boolean pointOnLine(Vector2 point, Line2 line){
            float dy = line.getEnd().getY() - line.getStart().getY();
            float dx = line.getEnd().getX() - line.getStart().getX();
            if (dx ==0f){
                return point.getX() == line.getStart().getX();
            }
            // y = gradient*x + c
            float gradient  = dy / dx;
            float c = line.getEnd().getY() - line.getEnd().getX()*gradient;
            return point.getY() == gradient * point.getX() + c;
        }
    public static boolean pointInRectangle(Vector2 point, Rect box){
        // Translate it inside the box space
        Vector2 pointLocalInTHeBox = new Vector2(point);
        pointLocalInTHeBox = Rotate.rotation(-box.getRotation(),pointLocalInTHeBox, box.getOrigin());


        //System.out.println(pointLocalInTHeBox.x+" "+pointLocalInTHeBox.y);
        // min is right top point max is left bottom
        Vector2 min = new Vector2(box.getOrigin());
        //System.out.println(box.getOrigin().x+" "+box.getOrigin().y);
        min.sub(new Vector2(box.getWidth(), box.getHeight()).mulRet(0.5));
        //System.out.println(box.getOrigin().x+" "+box.getOrigin().y);
        Vector2 max = new Vector2(box.getOrigin());
        //System.out.println(box.getOrigin().x+" "+box.getOrigin().y);
        max.add(new Vector2(box.getWidth(), box.getHeight()).mulRet(0.5));
        // If middle term is between others then it is in the box

        //System.out.println(min.getX()+" "+pointLocalInTHeBox.getX()+" "+max.getX());
        //System.out.println(min.getY()+" "+pointLocalInTHeBox.getY()+" "+max.getY());

        return pointLocalInTHeBox.getX() <=max.getX() && min.getX()<= pointLocalInTHeBox.getX() &&
                pointLocalInTHeBox.getY() <=max.getY() &&
                min.getY()<= pointLocalInTHeBox.getY();
    }


        public static boolean lineAndBoxNoRotation(Line2 line, Rect box){
            if (pointInRectangle(line.getStart(),box)||pointInRectangle(line.getEnd(),box)){
                return true;
            }
            Vector2 unitVector = new Vector2(line.getDirection());
            unitVector.normalise();

            unitVector.setX((unitVector.getX() !=0) ? 1.0f/unitVector.getX() :0f);
            unitVector.setY((unitVector.getY() !=0) ? 1.0f/unitVector.getY() :0f) ;

            Vector2 min = box.getOrigin();
            min.sub(new Vector2(box.width, box.height).mulRet(0.5));
            Vector2 max = box.getOrigin();
            max.add(new Vector2(box.width, box.height).mulRet(0.5));
            //TODO look at the raycasting closer;

            min.sub(line.getStart());
            min.x = min.x*unitVector.x;
            min.y = min.x*unitVector.y;

            max.sub(line.getStart());
            max.x = max.x*unitVector.x;
            max.y = max.x*unitVector.y;

            // TODO just make and x and y public

            float tmin = Math.max(Math.min(min.getX(),max.getX()),Math.min(min.getY(),max.getY()));
            float tmax = Math.min(Math.max(min.x,max.x),Math.max(min.y,max.y));
            if (tmax<0 || tmin>tmax){
                return false;
            }
            float t  =(tmax<0f) ? tmax: tmin;
            return t>0 && t*t < line.getDirection().getMagnitude();
        }


        public static boolean lineAndRectangle(Line2 line,Rect box) {
            float theta = -box.getRotation();
            Vector2 centre = box.getOrigin();
            Vector2 localStart = new Vector2(line.getStart());
            Vector2 localEnd = new Vector2(line.getEnd());

            localEnd = Rotate.rotation(theta, localStart, centre);
            localStart = Rotate.rotation(theta, localEnd, centre);

            Line2 localLine = new Line2(localStart, localEnd);
            //AABB aabb = new AABB(localStart,localEnd);
            // TODO delete bottom part



            return lineAndBoxNoRotation(localLine, new Rect((int)box.getPosition().x,(int)box.getPosition().y,box.getWidth(),box.getHeight(),1, Color.black,"hello"));
            //Ray vs. primitive tests
        }

        public boolean BoxAndBox(Rect b1, Rect b2){

        Vector2 xAxis = new Vector2(1,0);
        Vector2 xAxis1 = new Vector2(Rotate.rotation(b1.getRotation(),xAxis,new Vector2(0,0)));
        Vector2 xAxis2 = new Vector2(Rotate.rotation(b2.getRotation(),xAxis,new Vector2(0,0)));
        Vector2 yAxis = new Vector2(0,1);
        Vector2 yAxis1 = new Vector2(Rotate.rotation(b1.getRotation(),yAxis,new Vector2(0,0)));
        Vector2 yAxis2 = new Vector2(Rotate.rotation(b2.getRotation(),yAxis,new Vector2(0,0)));
        //System.out.println(xAxis2.x+" "+ xAxis2.y);


        Vector2 axesToTest[] = {xAxis1,yAxis1,xAxis2,yAxis2};
        for (int i = 0; i< axesToTest.length; i++) {
            if (!overlapOnAxis(b1, b2, axesToTest[i])) {
                return false;
            }
        }
            return true;

        }
            //TODO check whether this part is needed
            /*Vector2 axesToTest[] = {new Vector2(0,1),new Vector2(1,0),new Vector2(0,1),
                    new Vector2(1,0)};
            JMath.rotate(axesToTest[2],b2.getRigidbody().getRotation(),b2.getRigidbody().getPosition());
            JMath.rotate(axesToTest[3],b2.getRigidbody().getRotation(),b2.getRigidbody().getPosition());
            for (int i = 0; i< axesToTest.length; i++){
                if (!overlapOnAxis(b1,b2,axesToTest[i])){
                    return false;
                }
            }*/

    public boolean overlapOnAxis(Rect b1, Rect b2, Vector2 axis){
        Vector2 rangeB1 = getInterval(b1,axis);
        //System.out.println(rangeB1.x+" "+ rangeB1.y);
        Vector2 rangeB2 = getInterval(b2,axis);
        //System.out.println(rangeB2.x+" "+ rangeB2.y);
        //System.out.println(axis.x+" "+axis.y);
        boolean result = true;
        //System.out.println("b1 x and y "+rangeB1.x +" "+rangeB1.y+"  b2 and y "+rangeB2.x+" "+rangeB2.y);
        // return((rangeB2.y<=rangeB1.x) &&  (rangeB1.y<=rangeB2.x)
        if ((rangeB2.x<rangeB1.x && rangeB2.x < rangeB1.y)||
                (rangeB1.x<rangeB2.y && rangeB1.y<rangeB2.y)){
            result = false;
        }
        return result;
    }
    public Vector2 getInterval(Rect rect, Vector2 axis){
        Vector2 result  = new Vector2(0,0);

        ArrayList<Vector2> vertices = rect.getPoints();

        result.x = Multiply.dotProduct(axis, vertices.get(0));

        result.y = result.x;
        for (int i = 1; i<4; i++){
            float value = Multiply.dotProduct(vertices.get(i),axis);

            if (value > result.x){
                result.x = value;
            }
            if ( value < result.y){
                result.y = value;
            }
        }
        //System.out.println("overlap "+result.x+" "+result.y);
        return result;

    }
    public boolean lineAndLine(Line2 l1, Line2 l2){
        return false;

    }
    public boolean raycast(Ray2 ray, RaycastResult result, Rect box){
        Vector2 xAxis = new Vector2(Rotate.rotation(box.getRotation(),new Vector2(1,0),new Vector2(0,0)));
        Vector2 yAxis = new Vector2(Rotate.rotation(box.getRotation(),new Vector2(0,1),new Vector2(0,0)));
        Vector2 Centre = new Vector2(box.origin);
        Centre.sub(ray.getOrigin());
        float DotYaxis = Multiply.dotProduct(yAxis,Centre);
        float DotXaxis = Multiply.dotProduct(xAxis,Centre);
        float hWidth = (float) box.getWidth()/2;
        float hHeight = (float) box.getHeight()/2;
        Vector2 tMin =null;
        return false;
    }
    public RaycastResult LineAndRay(Ray2 ray, Line2 line){
        float a1,a2,b1,b2,c1,c2,x1,x2,y1,y2;
        Vector2 dir1 = new Vector2(ray.getDirection());
        a1 = -dir1.y;
        b1 = dir1.x;
        c1 = ray.getOrigin().y*dir1.x - ray.getOrigin().x*dir1.y;
        Vector2 dir2 = line.getDirection();
        a2 = -dir2.y;
        b2 = dir2.x;
        c2 = line.getStart().y*dir2.x - line.getStart().x*dir2.y;
        Vector2 intersection = EquationSolver.simultaneous_equations(a1,b1,c1,a2,b2,c2);
        // check whether it is NAN or not
        RaycastResult result = new RaycastResult();
        if (line.getStart().x<line.getEnd().x){
            x1 = line.getStart().x;
            x2 = line.getEnd().x;
        } else{
            x2 = line.getStart().x;
            x1 = line.getEnd().x;
        }
        //System.out.println(x1+" "+x2);
        if (line.getStart().y<line.getEnd().y){
            y1 = line.getStart().y;
            y2 = line.getEnd().y;
        } else{
            y2 = line.getStart().y;
            y1 = line.getEnd().y;
        }
        //System.out.println(y1+" "+y2);
        boolean hit = (x1-0.01f<=intersection.x )&&( intersection.x<=x2+0.01f) && (y1-0.01f<=intersection.y )&& (intersection.y<=y2+0.01f);
        Vector2 ToHit = new Vector2(intersection);
        ToHit.sub(ray.getOrigin());
        float dot = Multiply.dotProduct(ToHit,ray.getDirection());
        boolean fin = false;
        if ((hit) && (dot>=0f)){
             fin = true;
        }
        result.init(new Vector2(intersection),new Vector2(0,0),ToHit.getMagnitudeSquared(),fin);
        return result;

    }





    /*

    public static boolean raycast(Rect box, Ray2 ray, RaycastResult result){
        RaycastResult.reset(result);
        Vector2 size = box.getHalfSize();
        Vector2 xAxis = new Vector2(1,0);
        Vector2 yAxis = new Vector2(0,1);
        JMath.rotate(xAxis,-box.getRotation(), new Vector2(0,0));
        JMath.rotate(yAxis,-box.getRotation(), new Vector2(0,0));
        Vector2 p = new Vector2(box.getPosition()).sub(ray.getOrigin());
        Vector2 f = new Vector2(xAxis.dot(p),yAxis.dot(p));
        //project p on every axis of the box
        Vector2 e = new Vector2(xAxis.dot(p),yAxis.dot(p));
        float[] tArr = {0,0,0,0};
        for (int i =0;i<2; i++){
            if (JMath.compare(f.get(i),0)){
                //if ray is parrallel to the current axis, and the origin of the ray is not inside
                // we have no hit
                if(-e.get(i)-size.get(i)> 0|| -e.get(i)+size.get(i)<0){
                    return false;
                }
                f.setComponent(i,0.000001f);
                tArr[i*2 +0] = (e.get(i) + size.get(i)) / f.get(i);// tmax for this axis
                tArr[i*2 +1] = (e.get(i) - size.get(i)) / f.get(i); // tmin for this axis
            }
        }
        float tmin = Math.max(Math.min(tArr[0],tArr[1]),Math.min(tArr[2],tArr[3]));
        float tmax = Math.min(Math.max(tArr[0],tArr[1]),Math.max(tArr[2],tArr[3]));

        float t  =(tmax<0f) ? tmax: tmin;
        boolean hit = t> 0f; //&& t*t< ray.getMaximum()
        if (!hit){
            return false;
        }
        if (result!=null){
            Vector2 point = new Vector2(ray.getOrigin().add(new Vector2(ray.getDirection().mul(t))));
            Vector2 normal = new Vector2(point).sub(ray.getOrigin()).sub(point);
            normal.normalise();
            result.init(point,normal,t,true);
        }


        return true;

    }*/
}
        //-------------------------------------------------------------------
        //SAT helpers(Separation axis theorem)
        //------------------------------------------------------------------
            /*
        private static boolean overlapOnAxis(AABB b1, AABB b2, Vector2f axis){
            Vector2f rangeB1 = getInterval(b1,axis);
            Vector2f rangeB2 = getInterval(b2,axis);
            boolean result = true;
            // return((rangeB2.y<=rangeB1.x) &&  (rangeB1.y<=rangeB2.x)
            if ((rangeB2.x>=rangeB1.x && rangeB2.y > rangeB1.x)||
                    rangeB2.x<rangeB2.y && rangeB2.y< rangeB1.y){
                result = false;
            }
            return result;
        }
        // all combinations of reloaded methods for different object types
        private static boolean overlapOnAxis(AABB b1, Box2D b2, Vector2f axis){
            Vector2f rangeB1 = getInterval(b1,axis);
            Vector2f rangeB2 = getInterval(b2,axis);
            boolean result = true;
            // return((rangeB2.y<=rangeB1.x) &&  (rangeB1.y<=rangeB2.x)
            if ((rangeB2.x>=rangeB1.x && rangeB2.y > rangeB1.x)||
                    rangeB2.x<rangeB2.y && rangeB2.y< rangeB1.y){
                result = false;
            }
            return result;
        }*/


        /*public static boolean pointInCircle(Vector2 point, Circle circle){
        Vector2  circleCentre  = circle.getCentre();
        Vector2 Centretopoint = new Vector2(point);
        Centretopoint.sub(circleCentre);

        return Centretopoint.lengthSquared() <= circle.getRadius()*circle.getRadius();
    }
    public static boolean pointInAABB(Vector2f point, AABB aabb){
        Vector2f min = aabb.getMin();
        Vector2f max = aabb.getMax();

        return point.x <=max.x && min.x<= point.x && point.y <=max.y && min.y<= point.y;
    }*/

    // line vs Primitives tests
        /*public static boolean lineAndCircle(Line2 line, Circle circle){

            if (pointInCircle(line.getStart(),circle ) || (pointInCircle(line.getStart(),circle ))) {
                return true;
            }

            Vector2f ab = new Vector2f(line.getEnd().sub(line.getStart()));

            // project point circle position onto ab segment
            Vector2f circleCentre = circle.getCentre();
            Vector2f centreToLineStart = new Vector2f(circleCentre).sub(line.getStart());

            float t = centreToLineStart.dot(ab)/ab.dot(ab);

            if (t<0.0f || t>1.0f){
                return false;
            }

            Vector2f closestPoint = new Vector2f(line.getStart()).add(ab.mul(t));
            return pointInCircle(closestPoint, circle);
        }
         */


/*
        }


        public static boolean raycast(Circle circle, Ray2 ray, RaycastResult result){
            RaycastResult.reset(result);

            Vector2 originToCircle = new Vector2(circle.getCentre().sub(ray.getOrigin()));
            float radiusSquared = circle.getRadius()* circle.getRadius();
            float originToCircleLengthSquared = originToCircle.lengthSquared();

            //project vector formthe raty origin onto the direction of the ray
            float a = originToCircle.dot(ray.getDirection());
            float bSq = originToCircleLengthSquared - (a*a);
            if (radiusSquared - bSq < 0.0f){
                return false;
            }
            float f  = (float)Math.sqrt(radiusSquared- bSq);
            float t = 0f;
            if (originToCircleLengthSquared <radiusSquared){
                t = a + f;
            } else{
                t = a -f;
            }

            if (result !=null){
                Vector2f point = new Vector2f(ray.getOrigin()).add(new Vector2f(ray.getDirection()).mul(t));
                Vector2f normal = new Vector2f(point).sub(circle.getCentre());
                normal.normalize();
                result.init(point,normal,t, true);
            }
            return true;
        }
        */
    /*
        public static boolean raycast(Rect box, Ray2D ray, RaycastResult result){
            RaycastResult.reset(result);
            unitVector.normalize();

            unitVector.x = (unitVector.x !=0) ? 1.0f/unitVector.x :0f;
            Vector2 unitVector = ray.getDirection();
            unitVector.y = (unitVector.y !=0) ? 1.0f/unitVector.y :0f;

            Vector2f min = box.getMin();
            Vector2f max = box.getMax();

            min.sub(ray.getOrigin().mul(unitVector));
            max.sub(ray.getOrigin().mul(unitVector));

            float tmin = Math.max(Math.min(min.x,max.x),Math.min(min.y,max.y));
            float tmax = Math.min(Math.max(min.x,max.x),Math.max(min.y,max.y));
            if (tmax<0 || tmin>tmax){
                return false;
            }
            float t  =(tmax<0f) ? tmax: tmin;
            boolean hit = t> 0f; //&& t*t< ray.getMaximum()
            if (!hit){
                return false;
            }
            if (result!=null){
                Vector2 point = new Vector2(ray.getOrigin());
                point.add(new Vector2(ray.getDirection().mul(t))));
                Vector2 normal = new Vector2(point).sub(ray.getOrigin()).sub(point);
                normal.normalise();
                result.init(point,normal,t,true);
            }
            return true;

        }

        /*
        //    renamed for different order of the parameters
        public static boolean circleAndLine(Circle circle, Line2D line){
            return lineAndCircle(line, circle);
        }

        public  static boolean circleAndCircle(Circle c1, Circle c2){
            Vector2 vecBetweenCentres = new Vector2(c1.getCentre()).sub(c2.getCentre());
            float radiiSum = c1.getRadius() + c2.getRadius();
            return vecBetweenCentres.getMagnitudeSquared()<=radiiSum*radiiSum;
        }

        public static boolean circleaAndAABB(Circle c1,AABB box){
            Vector2 min  = box.getMin();
            Vector2 max = box.getMax();
            Vector2 closestPointToCircle = new Vector2f(c1.getCentre());
            if (closestPointToCircle.x <min.x){
                closestPointToCircle.x = min.x;
            } else if (closestPointToCircle.x > max.x){
                closestPointToCircle.x = max.x;
            }
            if (closestPointToCircle.y <min.y){
                closestPointToCircle.y = min.y;
            } else if (closestPointToCircle.y > max.y){
                closestPointToCircle.y = max.y;
            }
            Vector2f circleToBox = new Vector2f(c1.getCentre()).sub(closestPointToCircle);
            return circleToBox.lengthSquared() <= c1.getRadius()* c1.getRadius();
        }
        /*
        public static boolean circleAndBox(Circle circle, Rect box){
            // treat the box like aabb with rotated
            Vector2 min = new Vector2();
            Vector2 max = new Vector2(box.getHalfSize()).mul(2.0f);

            Vector2 r = new Vector2(circle.getCentre()).sub(box.getPosition());
            r.sub(box.getOrigin());
            JMath.rotate(r, -box.getRotation(),new Vector2(0,0));
            Vector2 localCirclePos = new Vector2(r).add(box.getHalfSize());
            Vector2 closestPointToCircle = new Vector2(localCirclePos);

            if (closestPointToCircle.x <min.x){
                closestPointToCircle.x = min.x;
            } else if (closestPointToCircle.x > max.x){
                closestPointToCircle.x = max.x;
            }
            if (closestPointToCircle.y <min.y){
                closestPointToCircle.y = min.y;
            } else if (closestPointToCircle.y > max.y){
                closestPointToCircle.y = max.y;
            }
            Vector2f circleToBox = new Vector2f(localCirclePos).sub(closestPointToCircle);
            return circleToBox.lengthSquared() <= circle.getRadius()* circle.getRadius();
        }
        public static boolean AABBAndCircle(AABB box, Circle circle){
            return circleaAndAABB(circle, box);
        }


        public static boolean AABBandAABB(AABB b1, AABB b2){
            // axis aligned
            Vector2 axesToTest[] = {new Vector2(0,1),new Vector2(1,0)};
            for (int i = 0; i< axesToTest.length; i++){
                if (!overlapOnAxis(b1,b2,axesToTest[i])){
                    return false;
                }
            }
            return true;

        }
        */
/*
        private Vector2 getInterval(Rect rect, Vector2 axis){
            Vector2 result  = new Vector2f(0,0);
            Vector2 min = rect.getMin();
            Vector2 max  = rect.getMax();
            Vector2 vertices[] = {new Vector2f(min.x,min.y), new Vector2f(min.x,max.y),
                    new Vector2f(max.x,min.y),new Vector2f(max.x,max.y)};
            result.x = axis.dot(vertices[0]);
            result.y = result.x;
            for (int i = 1; i<3; i++){
                float value = vertices[i].dot(axis);
                //float value  = axis.dot(vertices[i]);
                if (value > result.x){
                    result.x = value;
                }
                if ( value < result.y){
                    result.y = value;
                }
            }

            return result;

        }*/
        //overloaded method to be able to get Box2D as a parameter as well



