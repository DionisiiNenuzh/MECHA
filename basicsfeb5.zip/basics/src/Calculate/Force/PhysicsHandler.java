package Calculate.Force;

import Calculate.Vector2;
import Graphical.Rect;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

public class PhysicsHandler {
    private ForceRegistry registry;
    private List<Rect> bodies;
    private Gravity gravity;
    private double updateDt;
    private CollisionRegistry collisions;
    private FreeForce freeForce;

    public PhysicsHandler( Vector2 gravity){
        // list of forces acting on physical objects and time
        this.registry = new ForceRegistry();
        this.bodies = new ArrayList<>();
        this.updateDt = 0.016f;
        this.gravity = new Gravity(new Vector2(gravity));
        this.collisions = new CollisionRegistry();
        this.freeForce = new FreeForce(new Vector2(10,-10),"green");
    }
    public void update (double dt){
        // maybe use not fixed time update
        this.registry.updateForces((float)dt);

        this.collisionList(0);
        //System.out.println(this.collisions.registry2);
        //this.collisions.add(this.bodies.get(0), this.bodies.get(1));
        this.collisions.check();
        this.collisions.clear();


        for (int i  = 0; i <this.bodies.size();i++){
            this.bodies.get(i).updateForce(dt);
        }

        //System.out.println(this.collisions.registry2.size());
        this.collisions.clear();

        }
        public void addObject(Rect rect){
        this.bodies.add(rect);
        this.registry.add(this.gravity,rect);
        // adds free force on exact body
            /*
        if (this.freeForce.body.equals(rect.getId())){
            this.registry.add(this.freeForce,rect);
        }*/
    }
    // recursion that adds any possible pair of collisions
    public void collisionList(int pointer){
        if (pointer==this.bodies.size()-1) {
            //TODO quad trees and to use quad trees
        } else{
            for (int i = pointer+1;i<this.bodies.size();i++){
            collisions.add(this.bodies.get(pointer),this.bodies.get(i));

            }
            this.collisionList(pointer+1);
        }
    }
}
