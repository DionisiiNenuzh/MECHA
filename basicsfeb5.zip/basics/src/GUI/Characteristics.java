package GUI;public class Characteristics {
}
