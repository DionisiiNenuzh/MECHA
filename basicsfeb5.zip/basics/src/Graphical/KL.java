package Graphical;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class KL implements KeyListener {
    private boolean KeyPressedArr[] = new boolean[128];
    private String character;
    private char c;
    private int code;

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        KeyPressedArr[e.getKeyCode()] = true;
        this.code = e.getKeyCode();
        try {
            this.character = String.valueOf(e.getKeyChar());
            this.c = e.getKeyChar();
            System.out.println(this.character);
        }
        catch (Exception exception){
            //System.out.println("not a character");
        }

    }

    @Override
    public void keyReleased(KeyEvent e) {
        KeyPressedArr[e.getKeyCode()] =false;


    }
    public String getCharacter(){
        return this.character;
    }
    public Character getKey(){
        return this.c;
    }
    public void offCharacter(int i){
                this.KeyPressedArr[i]= false;
    }
    public boolean IsKeyPressed(int keyCode){
        return KeyPressedArr[keyCode];
    }
}
