package Graphical;

import Calculate.*;
import Calculate.Force.CollisionDetector;
import Calculate.Force.ForceGenerator;
import Calculate.Force.ReactionForce;

import java.awt.*;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.Dictionary;
//TODO Change doubles into the floats may take a lot of time

public class Rect {
    //attributes that are needed for the object
    public float mass,inversemass;
    public float height,width;
    public Vector2 position,origin;
    private Color color;
    private float rotationCurrent, rotationPrevious;
    private Matrix2 rotMat;
    private String id;
    // physical quantities
    public Vector2 ForceAccum = new Vector2(0,0);
    public Vector2 linearVel = new Vector2(0,0);
    private float angularVel, angularDamping = 0f;
    public boolean collided = false;
    private Vector2 linearDamping  = new Vector2(0,0);
    public ArrayList<Vector2> reactions = new ArrayList<Vector2>();
    public ArrayList<ReactionForce> ReactionForces ;

    private boolean fixedRot = false;

    private ArrayList<Vector2> points = new ArrayList<Vector2>();

    public void setRotationCurrent(float rotationCurrent) {
        this.rotationCurrent = rotationCurrent;
    }

    public int getHeight() {
        return (int) this.height;
    }

    public Vector2 getPosition() {
        return position;
    }

    public Vector2 getOrigin() {
        return origin;
    }

    public float getRotation() {
        return rotationCurrent;
    }

    public Rect(int xc, int yc, int h, int w, float m, Color c,String name){
        // assign all the attributes
        // TODO make getters and setters
        this.angularDamping = 1f;
        this.height = h;
        this.width = w;
        this.mass = m;
        this.id = name;
        // mass is 0 we use it for static objects
        // also use for validation of to avoid infinity error
        if (mass == 0.0f){this.inversemass = 0;}
        else{this.inversemass = 1/this.mass;}
        this.color = c;
        // TODO get rid off position may
        this.position = new Vector2(xc,yc);
        this.origin = new Vector2(xc,yc);
        origin.add(new Vector2(width/2,height/2));
        this.rotationCurrent = 0f;
        this.rotationPrevious = 0f;
        this.ReactionForces = new ArrayList<ReactionForce>();
        this.rotMat = new Matrix2(Math.cos(rotationCurrent),-Math.sin(rotationCurrent),Math.sin(rotationCurrent),Math.cos(rotationCurrent));
        //order of points 0,1,2,3 in left top, right top, right bottom, left bottom
        this.points.add(position);
        this.points.add(new Vector2(position.getX()+width, position.getY()));
        this.points.add(new Vector2(position.getX()+width,position.getY()+height));
        this.points.add(new Vector2(position.getX(),position.getY()+height));
    }
    public void draw(Graphics2D g2){
        g2.setColor(color);
        //  draws a line from 0 to 1 , 1 to 2, 2 to 3, 3 to 0
        //int[] new int[] {}
        g2.setStroke(new BasicStroke(5));
        for (int i= 1;i<4;i+=1){
            g2.draw(new Line2D.Float(points.get(i-1).getX()+Constants.SCREEN_OFFSET,points.get(i-1).getY(),
                    points.get(i).getX()+Constants.SCREEN_OFFSET,points.get(i).getY()));
        }
        g2.draw(new Line2D.Float(points.get(0).getX()+Constants.SCREEN_OFFSET,points.get(0).getY(),
                points.get(3).getX()+Constants.SCREEN_OFFSET,points.get(3).getY()));
        // think how to fill it inside
        //g2.fill(Polygon2D);

    }
    public ArrayList<Vector2> getPoints(){
        return this.points;
    }
    public void updatePoints(){
        //TODO sort out the order of rotation and translation maybe think about heavier use of matrices
        this.points.clear();
        float halfHeight = this.height/2;
        float halfWidth = this.width/2;


        this.points.add(new Vector2(this.origin.getX()-halfWidth, this.origin.getY()-halfHeight));
        this.points.add(new Vector2(this.origin.getX()+halfWidth,this.origin.getY()-halfHeight));
        this.points.add(new Vector2(this.origin.getX()+halfWidth,this.origin.getY()+halfHeight));
        this.points.add(new Vector2(this.origin.getX()-halfWidth,this.origin.getY()+halfHeight));
        for (int i = 0;i<4;i++){
            this.points.set(i,Rotate.rotation((double)this.rotationCurrent,this.points.get(i),this.origin));
        }
    }

    public void rotcheck(double f) {
        if (f> 1E-6){

        for (int i = 0; i < 4; i += 1) {
            updatePoints();
        }
        //float angle = this.rotationCurrent - this.rotationPrevious;
        //this.rotMat = new Matrix2(Math.cos(angle),-Math.sin(angle),Math.sin(angle),Math.cos(angle));
        //this.position =Rotate.rotation((double)(this.rotationCurrent - this.rotationPrevious), this.points.get(0), this.origin) ;
        //this.updateOrigin();
        this.rotationPrevious = this.rotationCurrent;
        }

    }
    // added new
    public void rotate(){
        // runs rotation procedure for all 4 points around origin
        if (this.rotationCurrent>7){
            this.rotationCurrent-=2*Math.PI;
            this.rotationPrevious-=2*Math.PI;
        }else if (this.rotationCurrent<-7){
            this.rotationCurrent+=2*Math.PI;
            this.rotationPrevious+=2*Math.PI;
        }
        for (int i = 0; i<4;i++){
            this.points.set(i,Rotate.rotation(this.rotationCurrent-this.rotationPrevious,this.points.get(i),this.origin));
        }
        this.rotationPrevious = this.rotationCurrent;
    }
    public void setLinearVel(Vector2 v) {
        if (this.mass != 0) {
            this.linearVel = v;
        }
    }
    public void updateOrigin(){
        this.origin = new Vector2(this.position);
        Vector2 halfSize = new Vector2(this.width,this.getHeight());
        this.origin.add(halfSize);
    }

    public void updateForce(double dt){
        //Calculate linear velocity
        //System.out.println("force without reactions"+this.ForceAccum.x+" "+this.ForceAccum.y);
        //System.out.println("size of reactions"+this.reactions.size());
        this.Moments(dt);
        //System.out.println(this.reactions.size());
        for (int i = 0; i<this.reactions.size();i++){
            this.ForceAccum.add(reactions.get(i));
        }
        //System.out.println(this.id);
        //System.out.println("force with reactions"+this.ForceAccum.x+" "+this.ForceAccum.y);
        Vector2 a = new Vector2(this.ForceAccum);
        //System.out.println("acceleration"+a.x+" "+a.y);
        a.mul(this.inversemass);
        //System.out.println(a.x+" "+a.y);
        if ((-0.001<a.x&&a.x<0.01)&&(-0.01<a.y&&a.y<0.01)){
            a.zero();
        }

        // look at it closer
        Vector2 tmp = a.mulRet(dt);
        this.linearVel.add(a.mulRet(dt));

        this.origin.add(new Vector2(this.linearVel.mulRet(dt)));
        //System.out.println(this.origin.x+" "+this.origin.y);
        //updateOrigin();
        updatePoints();
        zeroAccum();
        this.ReactionForces.clear();
        //System.out.println(this.reactions.size());
        this.reactions.clear();
        }
    public void addForceAdditional(Vector2 reaction, Rect box, Vector2 point){
        this.reactions.add(new Vector2(reaction));
        Vector2 pointContacting;
        this.ReactionForces.add(new ReactionForce(new Vector2(reaction),point));
        /*
        for (int i = 0; i<4; i++){
            CollisionDetector c = new CollisionDetector();
            if (c.pointInRectangle(this.points.get(i),box)){

                System.out.println("this is reaction at the contact"+i+"  "+this.points.get(i).x+" "+this.points.get(i).y);

            }

            //this.addForce(reaction);

        }*/

    }
    public void Moments(double dt){

        if (this.ReactionForces.size()>0){
            float moment;
            float Total = 0;
            Vector2 distance;
            EquationSolver e = new EquationSolver();
            if (this.id.equals("green")){
                System.out.println(this.id);
            }

            System.out.println(this.ReactionForces.size());

        for (int i = 0; i < this.ReactionForces.size(); i++) {
            distance = new Vector2(this.ReactionForces.get(i).contactPoint);
            distance.sub(this.origin);
            // the magnitude of the moment
            if (this.id.equals("green")){
                System.out.println("reactions"+this.ReactionForces.size());
                System.out.println("this is distance to the contact"+distance.x+" "+distance.y);
            }

            Vector2 normal = e.equation(distance.x, distance.y,0);
            moment = Math.abs(Multiply.dotProduct(normal,this.ReactionForces.get(i).Reaction));
            if (this.id.equals("green")){
                System.out.println("moment about is"+moment);
            }

            // determine the clockwise or anticlockwise;
            //TODO look at parrallel case


            if ((distance.x>0 &&normal.x<0)||(distance.x<0 && normal.x>0)){
                normal.mul(-1);
            }
            if (Multiply.dotProduct(normal,this.ReactionForces.get(i).Reaction)<0){
                //anticlockwise moment
                moment = -moment;
            }

            Total +=1f*moment;

        }
            if (this.id.equals("green")){
                System.out.println("total moment is "+Total);
            }

            float a =Total;
            float Inertia =(this.width*this.width+this.height*this.height)*12;
            a=a*this.inversemass/Inertia*10000;
            /*if (-0.2<a&&a<0.2){
                a = 0;
            }*/

            // look at it closer
            //Vector2 tmp = a.mulRet(dt);
            this.angularVel=a*(float)dt;

            this.rotationCurrent +=this.angularDamping*this.angularVel*dt;
            /*if (this.collided){
                this.angularVel =0;
            }*/
            if (this.id.equals("green")){
                System.out.println("Rotation is "+this.rotationCurrent);
            }

            //System.out.println(this.reactions.size());


        }
    }
        public void addForce(Vector2 force){
        this.ForceAccum.add(force);


        }
        public void zeroAccum(){
        this.ForceAccum = new Vector2(0f,0f);

        }


    public void update(double dt){
        //this.rotationCurrent +=100*dt;
        this.updateForce(dt);
        this.rotcheck(dt);

    }
    public float getMass() {
        return mass;
    }

    public void setMass(float mass) {
        this.mass = mass;
    }

    public float getInversemass() {
        return inversemass;
    }


    public void setInversemass(float inversemass) {
        this.inversemass = inversemass;
    }
    public String getId(){
        return this.id;
    }
    public Vector2 getForceAccum(){
        return new Vector2(this.ForceAccum);
    }
    public int getWidth() {
        return (int)this.width;
    }
    public void setPosition(Vector2 val){
        this.position = new Vector2(val);
    }
}
