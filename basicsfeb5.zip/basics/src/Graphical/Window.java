package Graphical;
import Calculate.Force.Gravity;
import Calculate.Force.PhysicsHandler;
import Calculate.Vector2;
import GUI.*;
import GUI.Button;
import GUI.Panel;
import com.sun.jdi.Field;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;

public class Window extends JFrame implements Runnable {
// class that uses graphics
    Graphics2D g2;
    KL keyListener = new KL();
    ML ml = new ML();
    objectsRegister objects = new objectsRegister();
    Button play,create;
    Vector2 Pointer;
    Panel menu;
    OutputWin Out;
    MakeRectangle Inputwindow = new MakeRectangle();

    public Window(){
        // initialisation of the window
        this.setSize(Constants.SCREEN_WIDTH,Constants.SCREEN_HEIGHT);
        this.setTitle(Constants.SCREEN_TITLE);
        this.setVisible(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.addKeyListener(keyListener);
        g2 = (Graphics2D)this.getGraphics();
        this.play  = new Button(new Vector2(0,0),new Vector2(147,25),"play", new PlayButton());
        this.create = new Button(new Vector2(0,0),new Vector2(147,25),"Create", new CreateButton(new Vector2(0,0),
                new Vector2(0,0)));

        this.menu = new Panel(new Vector2(0,30));
        this.menu.add(new Button(this.play));
        this.menu.add(this.create);
        this.Out = new OutputWin(new Vector2(150,40), new Vector2(230, 200),"Output Window",new OutputResponse());
        this.Inputwindow = new MakeRectangle();
        this.Inputwindow.initComponents();
        //this.Inputwindow



        /*JPanel panel = new JPanel();
        JButton button = new JButton("hello");
        panel.setBorder(BorderFactory.createEmptyBorder(30,30,10,30));
        panel.setLayout(new GridLayout(0,1));

        panel.add(button);
        button.getMousePosition();
        this.add(panel, BorderLayout.SOUTH);
        this.setTitle("hello");
        //this.pack();
        this.setVisible(true);*/
    }

    // drawing of each object at separate coordinates
    public void update(double dt){
        Image dbImage = createImage(getWidth(),getHeight());
        Graphics dbg = dbImage.getGraphics();
         if (this.menu.buttons.get(0).response.getActive()){
        this.objects.update(dt);}
        this.draw(dbg);
        g2.drawImage(dbImage,0,0,this);
// way how to listen to the keyboard presses

    }
    //LOOP that runs continuosly
    // needed for smoother frame rate
    public void draw(Graphics g){
        Graphics2D g2 = (Graphics2D)g;
        g2.setColor(Color.LIGHT_GRAY);
        g2.fillRect(Constants.SCREEN_OFFSET,0, Constants.SCREEN_WIDTH,Constants.SCREEN_HEIGHT);
        this.objects.draw(g2);
        //System.out.println("this was next");

        this.Out.draw(g2);
        this.menu.draw(g2);
        //System.out.println("this was last ");

        //g2.fillPolygon(new int[] {900, 1000, 1050},new int[] {600,500,550},3);
        //Background color fill
        // drawing all objects that are on the screen
    }
    public void inputWindow(){
        /*this.Inputwindow = new JFrame();
        this.Inputwindow.setSize(300,200);
        this.Inputwindow.setLocation(600,500);
        this.Inputwindow.setTitle("input window");
        Container container =new Container();
        //container.add
        container.add(new JTextField(10));
        this.Inputwindow.add(container);*/

    }
    public void run(){
        double lastFrameTime = 0.0;
        this.addMouseListener(this.ml);
        this.addKeyListener(this.keyListener);


        this.objects.add(new Rect(300,300,20, 20, 1,Color.green,"green"));
        this.objects.add(new Rect(250,100,20, 20, 10f,Color.red,"red"));
        this.objects.add(new Rect(100,700,0, 600, 0f,Color.black,"ground"));
        this.objects.add(new Rect(270,-50,10, 10, 100f,Color.yellow,"yellow"));
        this.objects.getItem(2).setRotationCurrent(0.44f);
        this.Out.ChangeSubject(this.objects.getItem(1));

        PhysicsHandler Phsystem = new PhysicsHandler(new Vector2(0,49));
        boolean Click = false;
        //Phsystem.addObject(objects.queue.get[0]);
        boolean done = true;
        this.create.response.panel.buttons.get(0).AssignInputWindow(this.Inputwindow);


        while(true){
            //Click = this.ml.pressed;

            Pointer = new Vector2(this.ml.getLocation());
            boolean click = ml.getClick();
            this.menu.OnMenu(Pointer,click,this.keyListener.getCharacter());
            this.objects.create(this.create.response.panel.buttons.get(0));
            this.create.response.panel.buttons.get(0).getRespond();

            this.Out.CheckHighlight(Pointer, click);
            //if (this.create.response.panel.buttons.get(0).response.Active){
                //this.create.response.panel.buttons.get(0).setInputWindow(this.Inputwindow);
                //this.create.response.panel.buttons.get(0).checkInput(this.Inputwindow);

            /*
            if (done){
                this.objects.add(new Rect(0,0,5,5,5,Color.pink,"pink"));
                done = false;
            }*/

            /*if (this.create.response.panel.buttons.get(0).response.respond){
                System.out.println("input is ready");
                int[] properties = this.Inputwindow.getNumbers();
                this.objects.add(new Rect(properties[0],properties[1],100,100,properties[2],Color.pink,"pink"));
                this.Inputwindow.setUnready();
            }
            else {
                //this.Inputwindow.setReady();
            }*/


            //if (this.keyListener.IsKeyPressed(KeyEvent.getExtendedKeyCodeForChar(this.keyListener.getKey()))){
                //this.create.response.panel.inputKey(this.keyListener.getCharacter());
               // this.keyListener.offCharacter(KeyEvent.getExtendedKeyCodeForChar(this.keyListener.getKey()));
            //}

            //System.out.println(this.Out.getPosition().x+" "+this.Out.getPosition().y);
            //System.out.println(this.Out.getSize().x+" "+this.Out.getSize().y);


            //System.out.println("the mouse is on "+ Pointer.getX()+" "+Pointer.getY());


            // gets the time of one frame to update frame depending on dt
            double time = Time.getTime();
            double deltaTime = time - lastFrameTime;
            lastFrameTime = time;
            this.update(deltaTime);


        }
    }
}
