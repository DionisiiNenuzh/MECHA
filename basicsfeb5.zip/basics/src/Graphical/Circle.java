package Graphical;

import Calculate.Vector2;

public class Circle {
    private Vector2 origin;
    private float radius,mass;
    private Vector2 ForceAccum;

    }

