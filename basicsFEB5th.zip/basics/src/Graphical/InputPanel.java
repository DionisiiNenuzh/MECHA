package Graphical;

import Calculate.Force.CollisionDetector;
import Calculate.Vector2;
import GUI.Panel;

import java.awt.*;

public class InputPanel extends Panel {

    public InputPanel(Vector2 v) {
        super(v);
    }
    public void inputKey(String c){
        //System.out.println("this is input in the panelsssssss");
        if (this.buttons.size()>0){
            for (int i = 0; i <this.buttons.size() ; i++) {
                this.buttons.get(i).inputKey(c);
            }
        }

    }
    public void OnMenu(Vector2 point,boolean click,String ch){
        CollisionDetector c = new CollisionDetector();
        //System.out.println("this is input in the panel");
        this.inputKey(ch);

        if (c.pointInRectangle(point,new Rect((int)this.position.x,(int)this.position.y,(int)this.size.y,(int)this.size.x,
                10, Color.red,""))){
            for (int i = 0;i<this.buttons.size(); i++){
                this.buttons.get(i).CheckHighlight(point,click,ch);
            }
        } else{
            //this.buttons.off();
        }


    }
}
