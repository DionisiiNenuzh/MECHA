package GUI;

public class Characteristics {
    public MakeRectangle input;
    public boolean Visible,responding;
    public Button button;
    public String name = "hell0";
    public Characteristics(Button button){
        this.input = new MakeRectangle();
        this.input.initComponents();
        this.responding =false;
        this.Visible = false;
        this.button = button;

    }
    public void update(){
        this.Visible = this.button.response.Active;
        this.input.setVisible(this.Visible);
        this.responding = this.input.ready;
        this.button.response.respond = this.responding;

    }
    public int[] getNumbers(){
        return this.input.getNumbers();
    }


    }
