package Calculate;

public class Vector2 {
    public float x,y;
    private float magnitude, magnitudeSquared;
    public Vector2(float x, float y){
        this.x = x;
        this.y = y;
    }
    public Vector2(Vector2 vec){
        this.x =vec.getX();
        this.y = vec.getY();    }

    public float getX() {
        return x;
    }
    public float getY() { return y; }

    public void add(Vector2 vec){
        this.x += vec.getX();
        this.y += vec.getY();    }

    public void sub(Vector2 vec){
        this.x -= vec.getX();
        this.y -= vec.getY();
    }
    public void mul(float factor){
        this.x = this.x*factor;
        this.y = this.y*factor;
    }
    public void mul(double factor){
        this.x = this.x*(float) factor;
        this.y = this.y*(float) factor;
    }
    public void normalise(){
        this.mul(1/this.getMagnitude());
    }
    public float getMagnitudeSquared(){
        return this.x*this.x +this.y*this.y;
    }
    public float getMagnitude(){
        return (float)Math.sqrt((this.getMagnitudeSquared()));
    }

    public void setX(float x) {
        this.x = x;
    }

    public void setY(float y) {
        this.y = y;
    }
    public void zero(){
        this.x = 0f;
        this.y = 0f;

    }
    public Vector2 mulRet(double factor){
        return new Vector2(this.x*(float) factor,this.y*(float) factor);
    }
    public float dot(Vector2 vec){
        return this.x*vec.getX()+this.y*vec.getY();
    }


}
