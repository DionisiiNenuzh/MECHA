package Test;

public class PrimitiveTests {
}
