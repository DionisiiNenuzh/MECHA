package GUI;

public class ButtonResponse {
    public boolean Active = false;
    public ButtonResponse(){

    }
    public void activate(){

    }
    public void DropDown(){

    }
    public boolean getActive(){
        return this.Active;
    }

}

