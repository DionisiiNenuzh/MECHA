package GUI;

import Calculate.Vector2;

import java.awt.*;
import java.util.ArrayList;

public class Panel {
    public ArrayList<Button> buttons = new ArrayList<Button>();
    public Vector2 position;
    private Vector2 buttonSpacing = new Vector2(0,30);
    public Panel(Vector2 v){
        this.position = new Vector2(v);


    }
    public void init(){
        this.buttons.get(0).setPosition(this.position);
        if (this.buttons.size()>1) {
            for (int i = 1; i < this.buttons.size(); i++) {
                Vector2 pos = new Vector2(this.buttons.get(i - 1).getPosition());
                pos.add(this.buttonSpacing);
                this.buttons.get(i).setPosition(pos);
            }
        }
    }
    public void add(Button b){
        this.buttons.add(b);

    }
    public void off(){
        for (int i = 0; i < this.buttons.size(); i++) {
            this.buttons.get(i);

        }
    }
    public void draw(Graphics2D g2){
        init();
        for (int i = 0;i<this.buttons.size(); i++){
            this.buttons.get(i).draw(g2);
        }
    }
    public void OnMenu( Vector2 point,  boolean click){
        if (point.getX()<150){
        for (int i = 0;i<this.buttons.size(); i++){
            this.buttons.get(i).CheckHighlight(point,click);
        }
    } else{
            //this.buttons.off();
        }


    }
}
