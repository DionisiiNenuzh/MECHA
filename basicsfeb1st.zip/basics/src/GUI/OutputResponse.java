package GUI;

public class OutputResponse extends ButtonResponse{
    public OutputResponse(){
        super();
    }

}
