package GUI;

import Calculate.Vector2;
import Graphical.Rect;

import java.awt.*;
import java.util.ArrayList;

public class OutputWin extends Button{
    private Vector2 positionHidden, sizeHidden,positionTrue, sizeTrue;
    private Vector2 position,size;
    public String name;
    public ArrayList<String> output = new ArrayList<String>();
    private boolean SetHighlight = false;
    boolean hidden = true;
    public Rect subject;
    public ButtonResponse response = new ButtonResponse();

    public OutputWin(Vector2 position, Vector2 size, String name, ButtonResponse response){
        super(position,size,name,response);
        this.name = name;
        this.positionTrue = new Vector2(size);
        this.sizeTrue = new Vector2(size);
        this.positionHidden = new Vector2(150,40);
        this.sizeHidden = new Vector2(10,10);
        this.initText();


    }
    public void ChangeSubject(Rect R){
        this.subject = R;
    }
    public void initText(){
        this.output.add("Name of the object");
        this.output.add("speed coordinates: ");
        this.output.add("speed in m/s: ");
        this.output.add("acceleration in m/s^2: ");
        this.output.add("Resultant force in N: ");
    }
    public void draw(Graphics2D g2){
        this.hideAndOpen();
        g2.setColor(Color.GRAY);
        g2.setStroke(new BasicStroke(5));

        g2.fillRect((int)this.position.getX(), (int)this.position.getY(),(int)this.size.getX(), (int)this.size.getY());
        // convert strings into less decimal places;
        g2.setColor(Color.BLACK);
        g2.drawString(this.name,(int)this.position.getX()+20, (int)this.position.getY()+20);
        float [] data = {this.subject.linearVel.getMagnitudeSquared(),this.subject.linearVel.getMagnitudeSquared(),
                this.subject.linearVel.getMagnitude(),this.subject.ForceAccum.getMagnitude()*this.subject.inversemass,
        this.subject.ForceAccum.getMagnitude()};
        this.writeDetails(g2,data);
        if (this.SetHighlight){
            this.highlight(g2);
        }



    }
    public String convert(int dp){

        return null;

    }

    public void writeDetails(Graphics2D g2, float[] data){
        int CharSpace = 8;
        int posX = (int)this.position.getX()+20;
        int posY= (int)this.position.getY()+20+4*CharSpace;
        g2.drawString(this.output.get(0),posX,posY);
        String s = String.valueOf(data[0]);

        g2.drawString(s,posX+this.output.get(0).length()*CharSpace, posY);
        for (int i = 1; i < this.output.size(); i++) {
            posY+=4*CharSpace;
            g2.drawString(this.output.get(i),posX, posY);
            s = String.valueOf(data[i]);
            g2.drawString(s,posX+this.output.get(i).length()*CharSpace, posY);
        }
    }



    public void hideAndOpen(){
        if (this.hidden){
            this.position = this.positionHidden;
            this.size = this.sizeHidden;
        }
        else {
            this.position = this.positionTrue;
            this.size = this.sizeTrue;
        }






    }
}
