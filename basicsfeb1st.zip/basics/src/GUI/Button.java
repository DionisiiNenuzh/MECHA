package GUI;

import Calculate.Force.CollisionDetector;
import Calculate.Vector2;
import Graphical.Rect;

import javax.swing.*;
import java.awt.*;

public class Button {
    private Vector2 position,size;
    public String name;
    private boolean SetHighlight = false;
    public ButtonResponse response = new ButtonResponse();
    public Button(Vector2 position, Vector2 size,String name, ButtonResponse response) {
        this.position = position;
        this.name = name;
        this.size = size;
        this.response = response;
    }
    public Button(Button b) {
        this.position = b.getPosition();
        this.name = b.name;
        this.size = b.getSize();
        this.response = b.response;
    }
    public void draw(Graphics2D g2){
        g2.setColor(Color.pink);
        g2.setStroke(new BasicStroke(5));

        g2.fillRect((int)this.position.getX(), (int)this.position.getY(),(int)this.size.getX(), (int)this.size.getY());
        g2.setColor(Color.darkGray);
        g2.drawString(this.name,(int)this.position.getX()+20, (int)this.position.getY()+20);
        if (this.SetHighlight){
            this.highlight(g2);
        }


    }
    public void highlight(Graphics2D g2){
        g2.setColor(Color.yellow);
        g2.setStroke(new BasicStroke(5));

        g2.drawRect((int)this.position.getX(), (int)this.position.getY(),(int)this.size.getX(), (int)this.size.getY());


    }
    public Vector2 getPosition() {
        return this.position;
    }

    public Vector2 getSize() {      return size;    }

    public void setSize(Vector2 size) {        this.size = size;    }

    public void setPosition(Vector2 position){        this.position = position;
    }
    public void CheckHighlight(Vector2 p,boolean click){
        CollisionDetector c = new CollisionDetector();
        if (c.pointInRectangle(p,new Rect((int)this.position.x,(int)this.position.y,(int)this.size.y,(int)this.size.x,
                10,Color.red,""))){
            SetHighlight = true;
            if (click) {
                this.response.activate();
            }
            //System.out.println("yes");
        }
        else{
            //System.out.println("not");
            SetHighlight = false;
        }
    }

}
