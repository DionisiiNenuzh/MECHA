package GUI;

import Calculate.Vector2;

import java.awt.*;

public class CreateButton extends ButtonResponse{
    public Panel dropdown;
    public Vector2 position,Size;
    public CreateButton(){
        super();
        this.dropdown = new Panel();
    }
    public void init(Button b){

    }
    public void draw(Graphics2D g2){

    }

}
