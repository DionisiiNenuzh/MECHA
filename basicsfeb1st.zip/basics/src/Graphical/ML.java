package Graphical;

import Calculate.Vector2;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class ML implements MouseListener {
    public boolean pressed, released;

    @Override
    public void mouseClicked(MouseEvent e) {


    }

    @Override
    public void mousePressed(MouseEvent e) {
        System.out.println("clicked");
        this.pressed = true;

    }

    @Override
    public void mouseReleased(MouseEvent e) {
        this.pressed = false;

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
    public Vector2 getLocation(){
        return new Vector2(MouseInfo.getPointerInfo().getLocation().x,MouseInfo.getPointerInfo().getLocation().y);
    }

}
