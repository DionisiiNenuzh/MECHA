package Graphical;

import javax.swing.*;

public class win extends JFrame implements Runnable {
    public win(int height, int width){
        this.setSize(width,height);
        this.setTitle("MECHA: helping engine");
        this.setVisible(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }
    public void run(){
        while(true){

        }
    }
}
