package Graphical;
import Calculate.Force.Gravity;
import Calculate.Force.PhysicsHandler;
import Calculate.Vector2;
import GUI.*;
import GUI.Button;
import GUI.Panel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;

public class Window extends JFrame implements Runnable {
// class that uses graphics
    Graphics2D g2;
    KL keyListener = new KL();
    ML ml = new ML();
    objectsRegister objects = new objectsRegister();
    Button play;
    Vector2 Pointer;
    Panel menu;
    OutputWin Out;

    public Window(){
        // initialisation of the window
        this.setSize(Constants.SCREEN_WIDTH,Constants.SCREEN_HEIGHT);
        this.setTitle(Constants.SCREEN_TITLE);
        this.setVisible(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.addKeyListener(keyListener);
        g2 = (Graphics2D)this.getGraphics();
        this.play  = new Button(new Vector2(0,0),new Vector2(147,25),"play", new PlayButton());

        this.menu = new Panel(new Vector2(0,30));
        this.menu.add(new Button(this.play));
        this.menu.add(new Button(new Vector2(0,0),new Vector2(147,25),"Create", new CreateButton()));
        this.Out = new OutputWin(new Vector2(600,300), new Vector2(100, 100),"Output Window",new OutputResponse());



        /*JPanel panel = new JPanel();
        JButton button = new JButton("hello");
        panel.setBorder(BorderFactory.createEmptyBorder(30,30,10,30));
        panel.setLayout(new GridLayout(0,1));

        panel.add(button);
        button.getMousePosition();
        this.add(panel, BorderLayout.SOUTH);
        this.setTitle("hello");
        //this.pack();
        this.setVisible(true);*/
    }

    // drawing of each object at separate coordinates
    public void update(double dt){
        Image dbImage = createImage(getWidth(),getHeight());
        Graphics dbg = dbImage.getGraphics();
         if (this.menu.buttons.get(0).response.getActive()){
        this.objects.update(dt);}
        this.draw(dbg);
        g2.drawImage(dbImage,0,0,this);
// way how to listen to the keyboard presses

    }
    //LOOP that runs continuosly
    // needed for smoother frame rate
    public void draw(Graphics g){
        Graphics2D g2 = (Graphics2D)g;
        g2.setColor(Color.LIGHT_GRAY);
        g2.fillRect(Constants.SCREEN_OFFSET,0, Constants.SCREEN_WIDTH,Constants.SCREEN_HEIGHT);
        objects.draw(g2);
        //System.out.println("this was next");
        this.menu.draw(g2);
        this.Out.draw(g2);
        //System.out.println("this was last ");

        //g2.fillPolygon(new int[] {900, 1000, 1050},new int[] {600,500,550},3);
        //Background color fill
        // drawing all objects that are on the screen
    }
    public void run(){
        double lastFrameTime = 0.0;
        this.addMouseListener(this.ml);


        this.objects.add(new Rect(300,150,50, 20, 1,Color.green,"green"));
        this.objects.add(new Rect(250,100,20, 20, 10f,Color.red,"red"));
        this.objects.add(new Rect(200,400,200, 600, 0f,Color.black,"ground"));
        this.Out.ChangeSubject(this.objects.getItem(0));

        PhysicsHandler Phsystem = new PhysicsHandler(new Vector2(0,49));
        boolean Click = false;
        //Phsystem.addObject(objects.queue.get[0]);


        while(true){
            //Click = this.ml.pressed;
            Pointer = new Vector2(this.ml.getLocation());
            this.menu.OnMenu(Pointer,this.ml.pressed);





            //System.out.println("the mouse is on "+ Pointer.getX()+" "+Pointer.getY());


            // gets the time of one frame to update frame depending on dt
            double time = Time.getTime();
            double deltaTime = time - lastFrameTime;
            lastFrameTime = time;
            this.update(deltaTime);


        }
    }
}
