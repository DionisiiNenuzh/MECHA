package Graphical;

public class Constants {
    public static final int SCREEN_HEIGHT = 800;
    public static final int SCREEN_WIDTH = 1100;
    public static final String  SCREEN_TITLE = "MECHAN";
    public static final float GRAVITY_g = 70f;
    public static final float COEFFICIENT_RESTITUTION_DEFAULT = 0.007f;
    public static final int SCREEN_OFFSET = 150;

    public static final int MAXNUM_OBJECTS_ON_SCREEN = 15;


}
