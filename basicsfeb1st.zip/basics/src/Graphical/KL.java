package Graphical;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;

public class KL implements KeyListener {
    private boolean KeyPressedArr[] = new boolean[128];
    public void MousePressed(){


    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        KeyPressedArr[e.getKeyCode()] = true;
        System.out.println(e.getKeyCode());

    }

    @Override
    public void keyReleased(KeyEvent e) {
        KeyPressedArr[e.getKeyCode()] =false;


    }
    public boolean IsKeyPressed(int keyCode){
        return KeyPressedArr[keyCode];
    }
}
