package Calculate.Force;

import Calculate.Line2;
import Calculate.Vector2;
import Graphical.Rect;

import java.awt.*;
import java.util.ArrayList;

public class CollisionRegistry {
    public ArrayList<Rect> registry1, registry2;
    public CollisionDetector  detector= new CollisionDetector();
    public Impulse Momentum = new Impulse();
    public CollisionRegistry(){
        this.registry1 = new ArrayList<>();
        this.registry2 = new ArrayList<>();
    }
    public void add(Rect body1, Rect body2){
        this.registry1.add(body1);
        this.registry2.add(body2);
        //System.out.println("add");
        //System.out.println(this.registry1.size());

    }
    public void check(){
        /*if (detector.lineAndBoxNoRotation(new Line2(new Vector2(0,0), new Vector2(100,100)),
                new Rect(9,2,30,30,1, Color.green))){
            System.out.println("it works");
        }
        else{System.out.println("it does not");}*/


        for (int i = 0;i<this.registry2.size();i++){

            if (detector.BoxAndBox(this.registry1.get(i),this.registry2.get(i))){
                System.out.println("There is a collision between "+ this.registry1.get(i).getId()+" "+ this.registry2.get(i).getId());
                // checks whether one of the objects is stationary
                if (this.registry1.get(i).getMass()==0f){
                    Momentum.stationary(this.registry1.get(i),this.registry2.get(i));

                } else if (this.registry2.get(i).getMass()==0f){
                    Momentum.stationary(this.registry2.get(i),this.registry1.get(i));
                }



                //this.registry2.get(i).linearVel.mul(-1f);
                //this.registry1.get(i).linearVel.mul(-1f);
                //detector.
                this.registry1.remove(i);
                this.registry2.remove(i);


            }
            else {
                //System.out.println("gg");
            }
        }

    }
    public void clear(){
        this.registry1.clear();
        this.registry2.clear();
    }


}
