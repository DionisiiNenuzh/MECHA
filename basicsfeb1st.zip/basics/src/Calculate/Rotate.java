package Calculate;

public class Rotate {
    // angle is passed in radians
    public static Matrix2 RotMatrix(float angle){
        return new Matrix2(Math.cos(angle),-Math.sin(angle),Math.sin(angle),Math.cos(angle));

    }
    public static Vector2 rotation(double angle, Vector2 point, Vector2 origin){
        Matrix2 mat = new Matrix2(Math.cos(angle),-Math.sin(angle),Math.sin(angle),Math.cos(angle));
        Vector2 temp = new Vector2(point);
        // so it is a rotations about the origin of the objects
        temp.sub(origin);
        temp = Multiply.transform(mat,temp);
        temp.add(origin);
        return temp;

    }
}
